
#!/usr/bin/env node

/**
 * Debug Portfolio Creation Issues
 * Comprehensive diagnostic tool for Base Sepolia portfolio creation
 */

// Polyfill for AbortController
if (typeof globalThis.AbortController === 'undefined') {
  const AbortController = require('abort-controller');
  globalThis.AbortController = AbortController;
}

require('dotenv').config({ path: './config/base-sepolia-pods-default.env' });
const { ethers } = require('ethers');

// Base Sepolia configuration
const BASE_SEPOLIA_CONFIG = {
  chainId: 84532,
  rpcUrl: 'https://sepolia.base.org',
  explorerUrl: 'https://sepolia.basescan.org',
  contracts: {
    plnToken: '0x9E1c51E1fAa1381D8a7Dbdd19402c5fCce9274C6',
    pollenDAO: '0xEF789258233E6cFBB5E0bb093FC9537E69e81Bb7',
    vePLN: '0x3a28AB567b661B3edaF9Ef0bDE9489558EDB3995',
    leagues: '0x55F04Ee2775925b80125F412C05cF5214Fd1317a'
  }
};

// Test bot (Conservative Bot)
const TEST_BOT = {
  id: 1,
  name: 'Conservative Bot',
  privateKey: 'd74ae2c1a798042c9bbf56f15d2649df6d114e763f9444e2cddcde050900f1d0',
  address: '0x561529036AB886c1FD3D112360383D79fBA9E71c',
  initialStake: '2'
};

// Contract ABIs
const PLN_TOKEN_ABI = [
  'function balanceOf(address) view returns (uint256)',
  'function approve(address spender, uint256 amount) returns (bool)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)'
];

const COMPREHENSIVE_POLLEN_DAO_ABI = [
  'function createPortfolio(uint256 _amount, uint256 _lockDuration) returns (address)',
  'function createPortfolio(uint256 _amount, uint256[] _weights, bool[] _isShort, bool _useVePLN) returns (address)',
  'function getUserPortfolio(address _user) view returns (address)',
  'function getPortfolio(address _user, address _token) view returns (uint256[], uint256, uint256, uint256, bool, uint256, uint256, bool[])',
  'function minStakeAmount() view returns (uint256)',
  'function maxStakeAmount() view returns (uint256)',
  'function minLockDuration() view returns (uint256)',
  'function maxLockDuration() view returns (uint256)',
  'function isWhitelisted(address _user) view returns (bool)',
  'function paused() view returns (bool)',
  'event PortfolioCreated(address indexed user, address indexed portfolio, uint256 amount, uint256 lockDuration)',
  'event PortfolioCreated(address indexed user, address indexed portfolio, uint256 amount)'
];

class PortfolioCreationDebugger {
  constructor() {
    this.provider = new ethers.JsonRpcProvider(BASE_SEPOLIA_CONFIG.rpcUrl);
  }

  async debugPortfolioCreation() {
    console.log('🔍 DEBUGGING PORTFOLIO CREATION');
    console.log('═'.repeat(50));

    try {
      // Network validation
      const network = await this.provider.getNetwork();
      console.log(`✅ Connected to ${network.name} (Chain ID: ${network.chainId})`);

      const wallet = new ethers.Wallet(TEST_BOT.privateKey, this.provider);
      console.log(`👤 Using test wallet: ${wallet.address}`);

      // Contract initialization
      const plnContract = new ethers.Contract(BASE_SEPOLIA_CONFIG.contracts.plnToken, PLN_TOKEN_ABI, wallet);
      const pollenDAO = new ethers.Contract(BASE_SEPOLIA_CONFIG.contracts.pollenDAO, COMPREHENSIVE_POLLEN_DAO_ABI, wallet);

      console.log('\n📊 BALANCE CHECK');
      console.log('─'.repeat(20));

      // Check balances
      const ethBalance = await this.provider.getBalance(wallet.address);
      const plnBalance = await plnContract.balanceOf(wallet.address);
      const allowance = await plnContract.allowance(wallet.address, BASE_SEPOLIA_CONFIG.contracts.pollenDAO);

      console.log(`💰 ETH Balance: ${ethers.formatEther(ethBalance)} ETH`);
      console.log(`💎 PLN Balance: ${ethers.formatEther(plnBalance)} PLN`);
      console.log(`🔓 PLN Allowance: ${ethers.formatEther(allowance)} PLN`);

      console.log('\n🔍 CONTRACT PARAMETERS');
      console.log('─'.repeat(25));

      // Check contract parameters
      try {
        const minStake = await pollenDAO.minStakeAmount();
        const maxStake = await pollenDAO.maxStakeAmount();
        const minLock = await pollenDAO.minLockDuration();
        const maxLock = await pollenDAO.maxLockDuration();

        console.log(`📊 Min Stake: ${ethers.formatEther(minStake)} PLN`);
        console.log(`📊 Max Stake: ${ethers.formatEther(maxStake)} PLN`);
        console.log(`⏰ Min Lock: ${minLock} seconds`);
        console.log(`⏰ Max Lock: ${maxLock} seconds`);
      } catch (paramError) {
        console.log(`⚠️ Could not fetch contract parameters: ${paramError.message}`);
      }

      // Check if user is whitelisted
      try {
        const isWhitelisted = await pollenDAO.isWhitelisted(wallet.address);
        console.log(`👥 Whitelisted: ${isWhitelisted}`);
      } catch (whitelistError) {
        console.log(`⚠️ Could not check whitelist status: ${whitelistError.message}`);
      }

      // Check if contract is paused
      try {
        const isPaused = await pollenDAO.paused();
        console.log(`⏸️ Contract Paused: ${isPaused}`);
      } catch (pauseError) {
        console.log(`⚠️ Could not check pause status: ${pauseError.message}`);
      }

      console.log('\n🔍 EXISTING PORTFOLIO CHECK');
      console.log('─'.repeat(30));

      // Check for existing portfolio
      try {
        const existingPortfolio = await pollenDAO.getUserPortfolio(wallet.address);
        if (existingPortfolio !== ethers.ZeroAddress) {
          console.log(`✅ Existing portfolio found: ${existingPortfolio}`);
          return;
        } else {
          console.log('📝 No existing portfolio found');
        }
      } catch (portfolioError) {
        console.log(`⚠️ Error checking existing portfolio: ${portfolioError.message}`);
      }

      console.log('\n🧪 TRANSACTION SIMULATION');
      console.log('─'.repeat(30));

      const stakeAmount = ethers.parseEther(TEST_BOT.initialStake);
      const lockDuration = 86400 * 7; // 7 days

      console.log(`💰 Stake Amount: ${TEST_BOT.initialStake} PLN`);
      console.log(`⏰ Lock Duration: ${lockDuration} seconds`);

      // Test gas estimation
      try {
        const gasEstimate = await pollenDAO.createPortfolio.estimateGas(stakeAmount, lockDuration);
        console.log(`⛽ Gas Estimate: ${gasEstimate.toString()}`);
      } catch (gasError) {
        console.log(`❌ Gas estimation failed: ${gasError.message}`);
        console.log(`   Reason: ${gasError.reason || 'Unknown'}`);

        // Try alternative portfolio creation method
        try {
          const weights = [16, 14, 14, 14, 14, 14, 14]; // Default weights
          const isShort = [false, false, false, false, false, false, false];
          const useVePLN = false;

          const altGasEstimate = await pollenDAO['createPortfolio(uint256,uint256[],bool[],bool)'].estimateGas(
            stakeAmount, weights, isShort, useVePLN
          );
          console.log(`⛽ Alternative Gas Estimate: ${altGasEstimate.toString()}`);
        } catch (altGasError) {
          console.log(`❌ Alternative gas estimation also failed: ${altGasError.message}`);
        }
      }

      console.log('\n🔧 APPROVAL CHECK');
      console.log('─'.repeat(20));

      if (allowance < stakeAmount) {
        console.log('🔓 Need to approve PLN spending...');
        
        try {
          const approveTx = await plnContract.approve(BASE_SEPOLIA_CONFIG.contracts.pollenDAO, stakeAmount, {
            gasLimit: 120000,
            gasPrice: ethers.parseUnits('0.1', 'gwei')
          });
          
          console.log(`📡 Approval transaction: ${approveTx.hash}`);
          await approveTx.wait();
          console.log('✅ PLN approved successfully');
          
        } catch (approveError) {
          console.log(`❌ Approval failed: ${approveError.message}`);
          return;
        }
      } else {
        console.log('✅ Sufficient PLN allowance already set');
      }

      console.log('\n🚀 ATTEMPTING PORTFOLIO CREATION');
      console.log('─'.repeat(40));

      try {
        const createTx = await pollenDAO.createPortfolio(stakeAmount, lockDuration, {
          gasLimit: 500000,
          gasPrice: ethers.parseUnits('0.1', 'gwei')
        });

        console.log(`📡 Transaction submitted: ${createTx.hash}`);
        console.log(`🔗 Explorer: ${BASE_SEPOLIA_CONFIG.explorerUrl}/tx/${createTx.hash}`);

        const receipt = await createTx.wait();
        console.log(`✅ Transaction confirmed in block: ${receipt.blockNumber}`);
        console.log(`⛽ Gas used: ${receipt.gasUsed.toString()}`);

        // Check for portfolio address
        const portfolioAddress = await pollenDAO.getUserPortfolio(wallet.address);
        if (portfolioAddress !== ethers.ZeroAddress) {
          console.log(`🎉 Portfolio created successfully: ${portfolioAddress}`);
        } else {
          console.log(`⚠️ Transaction succeeded but portfolio address not found`);
        }

      } catch (createError) {
        console.log(`❌ Portfolio creation failed:`);
        console.log(`   Error: ${createError.message}`);
        console.log(`   Code: ${createError.code}`);
        console.log(`   Reason: ${createError.reason || 'Unknown'}`);

        if (createError.transaction) {
          console.log(`   Failed TX: ${BASE_SEPOLIA_CONFIG.explorerUrl}/tx/${createError.transaction.hash}`);
        }
      }

    } catch (error) {
      console.error('❌ Debug session failed:', error);
    }
  }
}

// Run the debugger
async function main() {
  const debugger = new PortfolioCreationDebugger();
  await debugger.debugPortfolioCreation();
}

if (require.main === module) {
  main().catch(console.error);
}

module.exports = PortfolioCreationDebugger;
