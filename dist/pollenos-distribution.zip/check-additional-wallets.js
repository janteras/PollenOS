
require('dotenv').config({ path: require('path').resolve(__dirname, 'base-sepolia.env') });
const { ethers } = require('ethers');

// Extract private keys from codebase
const PRIVATE_KEYS = [
  // Bot wallets from config files
  'd74ae2c1a798042c9bbf56f15d2649df6d114e763f9444e2cddcde050900f1d0', // Bot 1 Conservative
  '241083ae625b93b41b555052840c09458c71704889b22774101d21b4d1482e62',  // Bot 2 Momentum
  '0aa4b2f50b7efc44721b23a2ef7fc3ab11b658369af23381752c6d86b42628b1',  // Bot 3 Technical
  '7dde37bea0f47ea849c9a7a285f3a277acd81c908accdb501ca036db1a5b11da',  // Bot 4 Mean Reversion
  '64da71a2688d24c0f970ded84d2d744081e467ae493f4c3256c4f8ee9bb959ee',  // Bot 5 Breakout
  
  // Additional keys from config/wallets.js
  'ca485bd6567e4c5fb5693ee66a5885d8',  // From API_KEYS section (might not be valid)
  'HG7DAYXKN5B6AZE35WRDVQRSNN5IDC3ZG6', // From API_KEYS section (might not be valid)
  
  // Test keys from scripts (these might be examples)
  'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
  '5f3159334556b9f3f3f5f3f3f5f3f3f5f3f3f5f3f3f5f3f3f5f3f3f5f3f3f5f',
  '6a0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f',
  '7b1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e1e'
];

// Base Sepolia configuration
const CONFIG = {
  RPC_URL: 'https://sepolia.base.org',
  CONTRACTS: {
    PLN: '0x9E1c51E1fAa1381D8a7Dbdd19402c5fCce9274C6',
    PORTFOLIO: '0x55F04Ee2775925b80125F412C05cF5214Fd1317a'
  }
};

// Contract ABIs
const ERC20_ABI = [
  'function balanceOf(address) view returns (uint256)',
  'function decimals() view returns (uint8)'
];

const PORTFOLIO_ABI = [
  'function getPortfolio(address user, address asset) view returns (uint256[], uint256)'
];

async function checkWallet(privateKey, index) {
  try {
    // Skip invalid keys
    if (!privateKey || privateKey.length !== 64) {
      console.log(`❌ Invalid key ${index + 1}: Invalid length`);
      return null;
    }
    
    // Add 0x prefix if not present
    const formattedKey = privateKey.startsWith('0x') ? privateKey : `0x${privateKey}`;
    
    const provider = new ethers.JsonRpcProvider(CONFIG.RPC_URL);
    const wallet = new ethers.Wallet(formattedKey, provider);
    const plnToken = new ethers.Contract(CONFIG.CONTRACTS.PLN, ERC20_ABI, wallet);
    const portfolio = new ethers.Contract(CONFIG.CONTRACTS.PORTFOLIO, PORTFOLIO_ABI, wallet);
    
    console.log(`\n🔍 Checking Wallet ${index + 1}:`);
    console.log(`   Address: ${wallet.address}`);
    console.log(`   Private Key: ${privateKey}`);
    
    // Get balances
    const [ethBalance, plnBalance, plnDecimals] = await Promise.all([
      provider.getBalance(wallet.address),
      plnToken.balanceOf(wallet.address),
      plnToken.decimals()
    ]);
    
    const ethFormatted = ethers.formatEther(ethBalance);
    const plnFormatted = ethers.formatUnits(plnBalance, plnDecimals);
    
    console.log(`   ETH Balance: ${ethFormatted} ETH`);
    console.log(`   PLN Balance: ${plnFormatted} PLN`);
    
    // Check if wallet has sufficient funds
    const hasETH = parseFloat(ethFormatted) >= 0.01; // At least 0.01 ETH for gas
    const hasPLN = parseFloat(plnFormatted) >= 2.0;   // At least 2 PLN for portfolio
    
    if (hasETH) console.log('✅ Sufficient ETH for gas');
    else console.log('❌ Insufficient ETH for gas');
    
    if (hasPLN) console.log('✅ Has PLN for portfolio creation');
    else console.log('❌ Insufficient PLN for portfolio creation');
    
    // Check for existing portfolio
    let hasPortfolio = false;
    try {
      const portfolioData = await portfolio.getPortfolio(wallet.address, CONFIG.CONTRACTS.PLN);
      if (portfolioData[1] > 0) {
        hasPortfolio = true;
        console.log('🗂️ Existing Portfolio Found');
        console.log(`   Total Value: ${ethers.formatUnits(portfolioData[1], plnDecimals)} PLN`);
      }
    } catch (error) {
      // Try with ETH address
      try {
        const portfolioData = await portfolio.getPortfolio(wallet.address, ethers.ZeroAddress);
        if (portfolioData[1] > 0) {
          hasPortfolio = true;
          console.log('🗂️ Existing ETH Portfolio Found');
          console.log(`   Total Value: ${ethers.formatEther(portfolioData[1])} ETH`);
        }
      } catch (error2) {
        console.log('📝 No existing portfolio found');
      }
    }
    
    // Determine if wallet is suitable for testing
    const isSuitable = hasETH && hasPLN && !hasPortfolio;
    
    if (isSuitable) {
      console.log('🎯 SUITABLE FOR TESTING');
      return {
        address: wallet.address,
        privateKey,
        ethBalance: ethFormatted,
        plnBalance: plnFormatted,
        hasPortfolio: hasPortfolio
      };
    } else {
      console.log('⚠️  Not suitable for testing');
      if (hasPortfolio) console.log('   Reason: Already has portfolio');
      if (!hasETH) console.log('   Reason: Insufficient ETH');
      if (!hasPLN) console.log('   Reason: Insufficient PLN');
      return null;
    }
    
  } catch (error) {
    console.error(`❌ Error checking wallet ${index + 1}:`, error.message);
    return null;
  }
}

async function main() {
  console.log('🔍 Searching for Additional Funded Wallets');
  console.log('═══════════════════════════════════════════════════════════');
  console.log(`Found ${PRIVATE_KEYS.length} private keys to check\n`);
  
  const availableWallets = [];
  
  for (let i = 0; i < PRIVATE_KEYS.length; i++) {
    const result = await checkWallet(PRIVATE_KEYS[i], i);
    if (result) {
      availableWallets.push(result);
    }
    
    // Add delay between checks
    if (i < PRIVATE_KEYS.length - 1) {
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
  
  console.log('\n🎉 SUMMARY: Available Wallets for Testing');
  console.log('═══════════════════════════════════════════════════════════');
  
  if (availableWallets.length > 0) {
    availableWallets.forEach((wallet, index) => {
      console.log(`\n${index + 1}. ${wallet.address}`);
      console.log(`   Private Key: ${wallet.privateKey}`);
      console.log(`   ETH Balance: ${wallet.ethBalance} ETH`);
      console.log(`   PLN Balance: ${wallet.plnBalance} PLN`);
      console.log(`   Portfolio: ${wallet.hasPortfolio ? 'EXISTS' : 'NONE'}`);
    });
    
    console.log(`\n✅ Found ${availableWallets.length} suitable wallet(s) for testing`);
    console.log('\nTo use any of these wallets for testing, update your script with:');
    console.log(`PRIVATE_KEY = "${availableWallets[0].privateKey}"`);
  } else {
    console.log('\n❌ No suitable wallets found for testing');
    console.log('   All wallets either lack funds or already have portfolios');
    console.log('\nOptions:');
    console.log('   1. Fund an existing wallet with PLN tokens');
    console.log('   2. Create a new wallet and fund it');
    console.log('   3. Use a wallet with existing portfolio for testing');
  }
}

// Run the script
main().catch(console.error);
