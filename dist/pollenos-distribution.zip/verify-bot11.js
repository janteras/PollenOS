
#!/usr/bin/env node

const { ethers } = require('ethers');

async function verifyBot11() {
  console.log('🔍 Verifying Bot 11 funding and configuration...\n');
  
  const provider = new ethers.JsonRpcProvider('https://sepolia.base.org');
  const privateKey = '1f684d93e5906902964c59749b106f6d04e0a9ec8174cb9b27bb55d14c63653c';
  
  try {
    // Derive address from private key
    const wallet = new ethers.Wallet(privateKey, provider);
    const derivedAddress = wallet.address;
    console.log(`✅ Derived address: ${derivedAddress}`);
    
    // Check ETH balance
    const ethBalance = await provider.getBalance(derivedAddress);
    console.log(`💰 ETH Balance: ${ethers.formatEther(ethBalance)} ETH`);
    
    // Check PLN token balance
    const plnTokenAddress = '0x9E1c51E1fAa1381D8a7Dbdd19402c5fCce9274C6';
    const plnAbi = ['function balanceOf(address) view returns (uint256)', 'function decimals() view returns (uint8)'];
    const plnContract = new ethers.Contract(plnTokenAddress, plnAbi, provider);
    
    const plnBalance = await plnContract.balanceOf(derivedAddress);
    console.log(`🌟 PLN Balance: ${ethers.formatEther(plnBalance)} PLN`);
    
    // Network verification
    const network = await provider.getNetwork();
    console.log(`🌐 Network: ${network.name} (Chain ID: ${network.chainId})`);
    
    // Funding status check
    const hasEthForGas = ethBalance > ethers.parseEther('0.001');
    const hasPlnForTrading = plnBalance > ethers.parseEther('1');
    
    console.log('\n📊 FUNDING STATUS:');
    console.log(`   ETH for gas: ${hasEthForGas ? '✅' : '❌'} (${hasEthForGas ? 'Sufficient' : 'Insufficient'})`);
    console.log(`   PLN for trading: ${hasPlnForTrading ? '✅' : '❌'} (${hasPlnForTrading ? 'Sufficient' : 'Insufficient'})`);
    
    if (hasEthForGas && hasPlnForTrading) {
      console.log('\n🎉 Bot 11 is ready for live trading!');
      return true;
    } else {
      console.log('\n⚠️ Bot 11 needs additional funding before trading');
      return false;
    }
    
  } catch (error) {
    console.error('❌ Verification failed:', error.message);
    return false;
  }
}

// Run verification
verifyBot11().then(success => {
  if (success) {
    console.log('\n🚀 Ready to launch multi-bot system with Bot 11!');
  }
  process.exit(success ? 0 : 1);
});
