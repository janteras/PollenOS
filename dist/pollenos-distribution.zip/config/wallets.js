module.exports = {
  BOTS: [
    {
      id: 1,
      name: 'conservative',
      privateKey: 'd74ae2c1a798042c9bbf56f15d2649df6d114e763f9444e2cddcde050900f1d0'
    },
    {
      id: 2,
      name: 'balanced',
      privateKey: '241083ae625b93b41b555052840c09458c71704889b22774101d21b4d1482e62'
    },
    {
      id: 3,
      name: 'aggressive',
      privateKey: '0aa4b2f50b7efc44721b23a2ef7fc3ab11b658369af23381752c6d86b42628b1'
    },
    {
      id: 4,
      name: 'arbitrage',
      privateKey: '7dde37bea0f47ea849c9a7a285f3a277acd81c908accdb501ca036db1a5b11da'
    },
    {
      id: 5,
      name: 'market_maker',
      privateKey: '64da71a2688d24c0f970ded84d2d744081e467ae493f4c3256c4f8ee9bb959ee'
    },
    {
      id: 6,
      name: 'scalping',
      privateKey: '01c9ebbb878c20446425a726bd4d47f99620afa3cfcb3103866337054949f87c'
    },
    {
      id: 7,
      name: 'grid_trading',
      privateKey: 'f56adb2c0b947f7d5f94c63b81a679dda6de49987bc99008779bb57827a600fe'
    },
    {
      id: 8,
      name: 'high_frequency',
      privateKey: 'bb835fbebd77b913b1e9df9d2088e4ed19493a551745bdffe990bc54cc51c6dd'
    },
    {
      id: 9,
      name: 'liquidity_provision',
      privateKey: '6798f078a4011ef08cf7c5e8c40a20c9e4e7042dd40a9b7a7f99aedfbc702e59'
    },
    {
      id: 10,
      name: 'cross_chain_arbitrage',
      privateKey: 'f7ca927b8dbeb8c58c72a2939901fc74aaef383f6e0a446bf3382b6264d9b47b'
    },
    {
      id: 11,
      name: 'test_integration',
      privateKey: '1f684d93e5906902964c59749b106f6d04e0a9ec8174cb9b27bb55d14c63653c'
    }
  ],
  API_KEYS: {
    INFURA: 'ca485bd6567e4c5fb5693ee66a5885d8',
    ETHERSCAN: 'HG7DAYXKN5B6AZE35WRDVQRSNN5IDC3ZG6'
  }
};
