
# PollenOS Local Deployment Guide

This guide will help you download, install, and run PollenOS on your local machine.

## System Requirements

- **Node.js**: v14 or higher
- **NPM**: v6 or higher
- **Operating System**: Windows, macOS, or Linux
- **RAM**: 4GB minimum, 8GB recommended
- **Storage**: 2GB free space

## Quick Start Installation

### 1. Download PollenOS

```bash
# Download the latest release
git clone https://github.com/your-repo/pollen-os.git
cd pollen-os

# Or download and extract the ZIP file
```

### 2. Run Automated Setup

```bash
# Install dependencies and configure system
npm run install:local

# Run interactive setup wizard
npm run setup
```

### 3. Configure Your Bots

The setup wizard will guide you through:
- Network configuration (Base Sepolia default)
- Wallet generation or import
- Trading strategy selection
- Risk management settings

### 4. Fund Your Bot Wallets

Each bot needs funding to operate:
- **Base Sepolia ETH**: For gas fees (0.01 ETH minimum per bot)
- **PLN Tokens**: For trading (10 PLN minimum per bot)

Get testnet funds from:
- Base Sepolia Faucet: https://www.quicknode.com/faucet/base-sepolia
- PLN Tokens: Available through the Pollen app

### 5. Launch the System

```bash
# Option 1: Launch trading bots directly
npm start

# Option 2: Launch with web interface
npm run config
```

## Web Configuration Interface

Access the web interface at: `http://localhost:3000`

Features:
- Bot configuration and management
- Real-time trading dashboard
- Performance monitoring
- Strategy adjustment
- Transaction logs

## Available Commands

```bash
# Core Operations
npm start                    # Start multi-bot trading system
npm run setup               # Interactive configuration wizard
npm run verify              # Verify system configuration

# Bot Management
npm run single-bot          # Run single bot for testing
npm run create-portfolios   # Create trading portfolios
npm run check-balances      # Check all wallet balances

# Configuration
npm run web-interface       # Launch web configuration UI
npm run backup              # Create configuration backup
npm run restore             # Restore from backup

# Development
npm run dev                 # Development mode with auto-restart
npm test                    # Run test suite
npm run lint                # Code linting
```

## Directory Structure

```
pollen-os/
├── config/                 # Configuration files
│   ├── .env               # Environment variables
│   └── wallets.js         # Bot wallet configurations
├── web-interface/         # Web configuration UI
├── src/                   # Core trading engine
├── scripts/               # Utility scripts
├── logs/                  # System logs
└── data/                  # Performance data
```

## Configuration Files

### Environment Variables (config/.env)
```bash
BASE_SEPOLIA_RPC_URL=https://sepolia.base.org
BASE_SEPOLIA_CHAIN_ID=84532
PLN_TOKEN_ADDRESS=0x9E1c51E1fAa1381D8a7Dbdd19402c5fCce9274C6
TRADING_ENABLED=true
LOG_LEVEL=info
```

### Bot Wallets (config/wallets.js)
Contains private keys and configurations for each trading bot.
**Security Warning**: Keep this file secure and never share private keys.

## Security Best Practices

1. **Private Key Management**
   - Store private keys securely
   - Use environment variables for production
   - Regular backups of wallet configurations

2. **Network Security**
   - Run behind firewall if exposing web interface
   - Use HTTPS in production environments
   - Monitor for unauthorized access

3. **Trading Safety**
   - Start with small amounts for testing
   - Monitor bot performance regularly
   - Set appropriate risk limits

## Troubleshooting

### Common Issues

**Installation Problems**
```bash
# Clear npm cache
npm cache clean --force

# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

**Bot Connection Issues**
```bash
# Check network connectivity
npm run verify

# Verify wallet funding
npm run check-balances

# Check system status
node check-system-status.js
```

**Portfolio Creation Errors**
```bash
# Create portfolios manually
npm run create-portfolios

# Diagnose portfolio issues
node diagnose-bot-portfolios.js
```

### Log Files

Monitor system logs for detailed information:
- `logs/multi-bot.log` - Main system logs
- `logs/error.log` - Error messages
- `logs/portfolio-creation.log` - Portfolio operations

## Performance Monitoring

The system provides comprehensive monitoring:
- Real-time bot performance metrics
- Portfolio value tracking
- Gas cost optimization
- Trading success rates

Access detailed performance data in the `data/performance/` directory.

## Support and Community

- **Documentation**: `docs/README.md`
- **Developer Guide**: `Sepolia-Developer-Guide.md`
- **Project Status**: `Pods-Status.md`

## Advanced Configuration

### Custom Strategies

Add custom trading strategies in `src/modules/strategy.js`:
```javascript
const customStrategy = {
  name: 'my-strategy',
  riskLevel: 'moderate',
  allocation: [40, 30, 30], // Asset allocation percentages
  signals: {
    // Custom trading signals
  }
};
```

### Multi-Network Deployment

Configure additional networks in `config/`:
- Copy Base Sepolia configuration
- Update RPC URLs and contract addresses
- Test thoroughly before live deployment

## Backup and Recovery

### Create Backup
```bash
npm run backup
```

### Restore Configuration
```bash
npm run restore <backup-file>
```

### Manual Backup
Important files to backup:
- `config/wallets.js` - Bot private keys
- `config/.env` - Environment configuration
- `data/performance/` - Performance history

---

**Ready to Trade!** 🚀

Your PollenOS system is now configured and ready for autonomous trading on the Base Sepolia network.
