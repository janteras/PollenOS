const express = require('express');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const WebSocket = require('ws');
const http = require('http');

class PollenConfigServer {
  constructor() {
    this.app = express();
    this.server = http.createServer(this.app);
    this.wss = new WebSocket.Server({ server: this.server });
    this.setupMiddleware();
    this.setupRoutes();
    this.setupWebSocket();
  }

  setupMiddleware() {
    this.app.use(cors());
    this.app.use(express.json());
    this.app.use(express.static(path.join(__dirname, '../public')));
  }

  setupRoutes() {
    // Serve main interface
    this.app.get('/', (req, res) => {
      res.sendFile(path.join(__dirname, '../public/index.html'));
    });

    // Get all bot configurations
    this.app.get('/api/bots', (req, res) => {
      try {
        const configPath = path.join(__dirname, '../../multi-bot-config.js');
        if (fs.existsSync(configPath)) {
          delete require.cache[require.resolve(configPath)];
          const { BOT_CONFIGS } = require(configPath);
          res.json(BOT_CONFIGS);
        } else {
          res.json({});
        }
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // Get single bot configuration
    this.app.get('/api/bots/:id', (req, res) => {
      try {
        const { BOT_CONFIGS } = require('../../multi-bot-config.js');
        const bot = BOT_CONFIGS[req.params.id];
        if (bot) {
          res.json(bot);
        } else {
          res.status(404).json({ error: 'Bot not found' });
        }
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // Update bot configuration
    this.app.put('/api/bots/:id', (req, res) => {
      try {
        const configPath = path.join(__dirname, '../../multi-bot-config.js');
        const { BOT_CONFIGS } = require(configPath);

        if (BOT_CONFIGS[req.params.id]) {
          BOT_CONFIGS[req.params.id] = { ...BOT_CONFIGS[req.params.id], ...req.body };

          // Write updated config back to file
          const configContent = `const BOT_CONFIGS = ${JSON.stringify(BOT_CONFIGS, null, 2)};

const BASE_SEPOLIA_CONFIG = {
  chainId: 84532,
  name: 'Base Sepolia',
  rpcUrl: 'https://sepolia.base.org',
  explorerUrl: 'https://sepolia.basescan.org',
  contracts: {
    plnToken: '0x9E1c51E1fAa1381D8a7Dbdd19402c5fCce9274C6',
    pollenDAO: '0xEF789258233E6cFBB5E0bb093FC9537E69e81Bb7',
    vePLN: '0x3a28AB567b661B3edaF9Ef0bDE9489558EDB3995',
    leagues: '0x55F04Ee2775925b80125F412C05cF5214Fd1317a'
  },
  gasPrice: '0.1',
  gasLimit: 500000,
  confirmations: 1
};

module.exports = {
  BOT_CONFIGS,
  BASE_SEPOLIA_CONFIG
};`;

          fs.writeFileSync(configPath, configContent);
          this.broadcastUpdate('bot_updated', { id: req.params.id, config: BOT_CONFIGS[req.params.id] });
          res.json(BOT_CONFIGS[req.params.id]);
        } else {
          res.status(404).json({ error: 'Bot not found' });
        }
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // Get system status
    this.app.get('/api/status', (req, res) => {
      try {
        const status = {
          timestamp: new Date().toISOString(),
          bots: this.getBotStatus(),
          network: 'Base Sepolia',
          trading: true
        };
        res.json(status);
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });

    // Start/stop trading
    this.app.post('/api/trading/:action', (req, res) => {
      const action = req.params.action;
      if (action === 'start' || action === 'stop') {
        this.broadcastUpdate('trading_' + action, { timestamp: new Date().toISOString() });
        res.json({ success: true, action: action });
      } else {
        res.status(400).json({ error: 'Invalid action' });
      }
    });

    // Export configuration
    this.app.get('/api/export', (req, res) => {
      try {
        const { BOT_CONFIGS, BASE_SEPOLIA_CONFIG } = require('../../multi-bot-config.js');
        const exportData = {
          bots: BOT_CONFIGS,
          network: BASE_SEPOLIA_CONFIG,
          timestamp: new Date().toISOString()
        };
        res.json(exportData);
      } catch (error) {
        res.status(500).json({ error: error.message });
      }
    });
  }

  setupWebSocket() {
    this.wss.on('connection', (ws) => {
      console.log('Client connected to WebSocket');

      ws.on('message', (message) => {
        try {
          const data = JSON.parse(message);
          console.log('Received:', data);
        } catch (error) {
          console.error('Invalid WebSocket message:', error);
        }
      });

      ws.on('close', () => {
        console.log('Client disconnected from WebSocket');
      });
    });
  }

  broadcastUpdate(type, data) {
    const message = JSON.stringify({ type, data, timestamp: new Date().toISOString() });
    this.wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  getBotStatus() {
    try {
      const { BOT_CONFIGS } = require('../../multi-bot-config.js');
      const status = {};

      Object.keys(BOT_CONFIGS).forEach(id => {
        status[id] = {
          name: BOT_CONFIGS[id].name,
          strategy: BOT_CONFIGS[id].strategy,
          status: 'active',
          lastTrade: new Date().toISOString()
        };
      });

      return status;
    } catch (error) {
      return {};
    }
  }

  start(port = 5000) {
    this.server.listen(port, '0.0.0.0', () => {
      console.log(`🌐 PollenOS Configuration Interface running on http://0.0.0.0:${port}`);
      console.log(`📊 WebSocket server ready for real-time updates`);
      console.log(`🔗 Access the interface at: http://0.0.0.0:${port}`);
      console.log(`🔗 Replit Preview: Available in the webview on port ${port}`);
    });
  }
}

// Start server
if (require.main === module) {
  const server = new PollenConfigServer();
  server.start(process.env.PORT || 5000);
}

module.exports = PollenConfigServer;