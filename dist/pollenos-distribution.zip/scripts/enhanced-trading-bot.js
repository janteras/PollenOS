require('dotenv').config({ path: require('path').resolve(__dirname, '../base-sepolia.env') });
const { ethers } = require('ethers');
const winston = require('winston');
const { getLockedPollenContract, getPortfolioContract, getPollenTokenContract, getERC20Contract } = require('./contracts-config');
const config = require('./config');

// Enhanced logger with JSON formatting
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.splat(),
    winston.format.json()
  ),
  defaultMeta: { service: 'pollen-trading-bot' },
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    }),
    new winston.transports.File({ filename: 'logs/enhanced-pollen-bot.log' })
  ]
});

// Configuration
const BOT_CONFIG = {
  maxRetries: 3,
  initialRetryDelay: 1000, // 1 second
  maxFeePerGas: ethers.parseUnits('0.5', 'gwei'),
  maxPriorityFeePerGas: ethers.parseUnits('0.1', 'gwei'),
  healthCheckInterval: 30000, // 30 seconds
  maxConcurrentTrades: 3
};

class EnhancedTradingBot {
  constructor() {
    this.retryCount = 0;
    this.isRunning = false;
    this.activeTrades = new Set();
    this.initializeProvider();
    this.initializeContracts();
  }

  initializeProvider() {
    try {
      this.provider = new ethers.JsonRpcProvider(config.RPC_URL);
      
      // Add retry logic to the provider
      this.provider.on('debug', (data) => {
        if (data.action === 'response' && data.error) {
          logger.warn('Provider error:', data.error);
        }
      });
      
      // Initialize wallet with proper error handling
      let privateKey = process.env.WALLET_PRIVATE_KEY || '';
      
      // Ensure private key has 0x prefix
      if (privateKey && !privateKey.startsWith('0x')) {
        privateKey = '0x' + privateKey;
      }
      if (!privateKey) {
        throw new Error('WALLET_PRIVATE_KEY not found in environment variables');
      }
      
      this.wallet = new ethers.Wallet(privateKey, this.provider);
      logger.info(`Initialized wallet: ${this.wallet.address}`);
      
    } catch (error) {
      logger.error('Failed to initialize provider:', error);
      throw error;
    }
  }

  initializeContracts() {
    try {
      this.lockedPollen = getLockedPollenContract(this.wallet);
      this.portfolio = getPortfolioContract(this.wallet);
      this.pollenToken = getPollenTokenContract(this.wallet);
      logger.info('Initialized contracts');
    } catch (error) {
      logger.error('Failed to initialize contracts:', error);
      throw error;
    }
  }

  async withRetry(operation, operationName, maxRetries = BOT_CONFIG.maxRetries) {
    let lastError;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error;
        const delay = Math.min(
          BOT_CONFIG.initialRetryDelay * Math.pow(2, attempt - 1),
          30000 // Max 30 seconds
        );
        
        logger.warn(`Attempt ${attempt} failed for ${operationName}: ${error.message}`);
        
        if (attempt < maxRetries) {
          logger.info(`Retrying in ${delay}ms...`);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }
    
    throw new Error(`Operation '${operationName}' failed after ${maxRetries} attempts: ${lastError.message}`);
  }

  async checkNetworkHealth() {
    try {
      const network = await this.provider.getNetwork();
      const blockNumber = await this.provider.getBlockNumber();
      const gasPrice = await this.provider.getFeeData();
      
      logger.info({
        message: 'Network status',
        network: network.name,
        chainId: network.chainId,
        blockNumber,
        gasPrice: gasPrice.gasPrice?.toString(),
        maxFeePerGas: gasPrice.maxFeePerGas?.toString(),
        maxPriorityFeePerGas: gasPrice.maxPriorityFeePerGas?.toString()
      });
      
      return true;
    } catch (error) {
      logger.error('Network health check failed:', error);
      throw error;
    }
  }

  async getWalletBalance() {
    return this.withRetry(async () => {
      const balance = await this.provider.getBalance(this.wallet.address);
      const formattedBalance = ethers.formatEther(balance);
      logger.info(`Wallet balance: ${formattedBalance} ETH`);
      return balance;
    }, 'getWalletBalance');
  }

  async getPLNBalance() {
    return this.withRetry(async () => {
      const balance = await this.pollenToken.balanceOf(this.wallet.address);
      const formattedBalance = ethers.formatUnits(balance, 18); // Assuming 18 decimals
      logger.info(`PLN balance: ${formattedBalance} PLN`);
      return balance;
    }, 'getPLNBalance');
  }

  async getStakingInfo() {
    return this.withRetry(async () => {
      try {
        const lockInfo = await this.lockedPollen.locks(this.wallet.address);
        logger.info('Staking info:', {
          amount: lockInfo.amount.toString(),
          end: new Date(Number(lockInfo.end) * 1000).toISOString(),
          isActive: lockInfo.amount > 0 && lockInfo.end > Math.floor(Date.now() / 1000)
        });
        return lockInfo;
      } catch (error) {
        // Handle case where the locks function might not exist or revert
        if (error.message.includes('missing revert data') || error.code === 'CALL_EXCEPTION') {
          logger.warn('Could not fetch staking info - contract may not be deployed or ABI mismatch');
          return null;
        }
        throw error;
      }
    }, 'getStakingInfo');
  }

  async stakePLN(amount, lockDurationInDays = 30) {
    return this.withRetry(async () => {
      if (this.activeTrades.has('stake')) {
        throw new Error('Stake operation already in progress');
      }
      
      this.activeTrades.add('stake');
      
      try {
        // Convert amount to wei
        const amountWei = ethers.parseUnits(amount.toString(), 18);
        
        // Check allowance first
        const allowance = await this.pollenToken.allowance(
          this.wallet.address,
          this.lockedPollen.target
        );
        
        if (allowance < amountWei) {
          logger.info('Approving PLN for staking...');
          const approveTx = await this.pollenToken.approve(
            this.lockedPollen.target,
            ethers.MaxUint256
          );
          await approveTx.wait();
          logger.info('PLN approval confirmed');
        }
        
        // Calculate unlock timestamp (current time + lock duration)
        const unlockTime = Math.floor(Date.now() / 1000) + (lockDurationInDays * 24 * 60 * 60);
        
        logger.info(`Staking ${amount} PLN for ${lockDurationInDays} days...`);
        
        // Execute stake
        const tx = await this.lockedPollen.createLock(
          amountWei,
          unlockTime,
          {
            maxFeePerGas: BOT_CONFIG.maxFeePerGas,
            maxPriorityFeePerGas: BOT_CONFIG.maxPriorityFeePerGas
          }
        );
        
        const receipt = await tx.wait();
        logger.info(`Stake successful in block ${receipt.blockNumber}`);
        
        return receipt;
      } finally {
        this.activeTrades.delete('stake');
      }
    }, 'stakePLN');
  }

  async extendLock(additionalDays = 30) {
    return this.withRetry(async () => {
      if (this.activeTrades.has('extend')) {
        throw new Error('Extend operation already in progress');
      }
      
      this.activeTrades.add('extend');
      
      try {
        // Get current lock info
        const lockInfo = await this.getStakingInfo();
        
        if (!lockInfo || lockInfo.amount === 0n) {
          throw new Error('No active stake found to extend');
        }
        
        // Calculate new unlock time
        const currentEnd = Number(lockInfo.end);
        const newEnd = currentEnd + (additionalDays * 24 * 60 * 60);
        
        logger.info(`Extending lock by ${additionalDays} days to ${new Date(newEnd * 1000).toISOString()}`);
        
        // Execute extend
        const tx = await this.lockedPollen.increaseUnlockTime(
          newEnd,
          {
            maxFeePerGas: BOT_CONFIG.maxFeePerGas,
            maxPriorityFeePerGas: BOT_CONFIG.maxPriorityFeePerGas
          }
        );
        
        const receipt = await tx.wait();
        logger.info(`Lock extension successful in block ${receipt.blockNumber}`);
        
        return receipt;
      } finally {
        this.activeTrades.delete('extend');
      }
    }, 'extendLock');
  }

  async startHealthMonitor() {
    if (this.healthMonitorInterval) {
      clearInterval(this.healthMonitorInterval);
    }
    
    this.healthMonitorInterval = setInterval(async () => {
      try {
        await this.checkNetworkHealth();
        await this.getWalletBalance();
        await this.getPLNBalance();
        await this.getStakingInfo();
      } catch (error) {
        logger.error('Health monitor error:', error);
      }
    }, BOT_CONFIG.healthCheckInterval);
    
    logger.info('Health monitor started');
  }

  async stopHealthMonitor() {
    if (this.healthMonitorInterval) {
      clearInterval(this.healthMonitorInterval);
      this.healthMonitorInterval = null;
      logger.info('Health monitor stopped');
    }
  }

  async start() {
    if (this.isRunning) {
      logger.warn('Bot is already running');
      return;
    }
    
    this.isRunning = true;
    logger.info('Starting enhanced trading bot...');
    
    try {
      // Initial checks
      await this.checkNetworkHealth();
      await this.getWalletBalance();
      await this.getPLNBalance();
      await this.getStakingInfo();
      
      // Start health monitoring
      await this.startHealthMonitor();
      
      logger.info('Enhanced trading bot is running');
      
    } catch (error) {
      this.isRunning = false;
      logger.error('Failed to start bot:', error);
      throw error;
    }
  }

  async stop() {
    if (!this.isRunning) {
      logger.warn('Bot is not running');
      return;
    }
    
    logger.info('Stopping enhanced trading bot...');
    
    try {
      await this.stopHealthMonitor();
      this.isRunning = false;
      logger.info('Enhanced trading bot stopped');
    } catch (error) {
      logger.error('Error while stopping bot:', error);
      throw error;
    }
  }
}

// Example usage
async function main() {
  const bot = new EnhancedTradingBot();
  
  // Handle process termination
  process.on('SIGINT', async () => {
    console.log('\nGracefully shutting down...');
    await bot.stop();
    process.exit(0);
  });
  
  try {
    await bot.start();
    
    // Example: Stake 100 PLN for 30 days
    // await bot.stakePLN(100, 30);
    
    // Example: Extend lock by 30 days
    // await bot.extendLock(30);
    
  } catch (error) {
    console.error('Fatal error:', error);
    await bot.stop();
    process.exit(1);
  }
}

if (require.main === module) {
  main().catch(console.error);
}

module.exports = EnhancedTradingBot;
