require('dotenv').config({ path: require('path').resolve(__dirname, '../base-sepolia.env') });
const { ethers } = require('ethers');
const config = require('./config');

class TradingBot {
  constructor(id, strategy) {
    this.id = id;
    this.strategy = strategy;
    this.provider = new ethers.JsonRpcProvider(config.RPC_URL);
    this.wallet = new ethers.Wallet(process.env[`BOT_${id}_PRIVATE_KEY`], this.provider);
    this.isRunning = false;
    this.lastAction = null;
    
    // Initialize contracts
    this.vePLN = new ethers.Contract(
      config.CONTRACTS.VEPLN,
      ['function getLockInfo(address) view returns (uint256, uint256)'],
      this.wallet
    );
    
    this.portfolio = new ethers.Contract(
      config.CONTRACTS.PORTFOLIO,
      ['function getPortfolioDetails() view returns (address[], uint256[], uint256)'],
      this.wallet
    );
    
    console.log(`[Bot ${this.id}] Initialized with ${this.strategy.name} strategy`);
  }

  async start() {
    if (this.isRunning) {
      console.log(`[Bot ${this.id}] Already running`);
      return;
    }
    
    this.isRunning = true;
    console.log(`[Bot ${this.id}] Starting with ${this.strategy.name} strategy`);
    
    // Initial setup
    await this.initializeBot();
    
    // Start the main loop
    this.runLoop();
    
    // Set up interval for periodic execution
    this.interval = setInterval(() => this.runLoop(), config.BOTS.INTERVAL * 1000);
  }
  
  stop() {
    if (!this.isRunning) return;
    
    clearInterval(this.interval);
    this.isRunning = false;
    console.log(`[Bot ${this.id}] Stopped`);
  }
  
  async initializeBot() {
    try {
      console.log(`[Bot ${this.id}] Initializing...`);
      
      // Check PLN balance and staking status
      await this.checkStakingStatus();
      
      // Check portfolio allocation
      await this.checkPortfolio();
      
      console.log(`[Bot ${this.id}] Initialization complete`);
    } catch (error) {
      console.error(`[Bot ${this.id}] Initialization error:`, error.message);
      throw error;
    }
  }
  
  async checkStakingStatus() {
    try {
      const [amount, lockEnd] = await this.vePLN.getLockInfo(this.wallet.address);
      const lockDate = new Date(Number(lockEnd) * 1000);
      
      console.log(`[Bot ${this.id}] Staking Status:`);
      console.log(`  - Staked: ${ethers.formatEther(amount)} PLN`);
      console.log(`  - Lock ends: ${lockDate}`);
      
      // Check if staking is needed
      if (amount === 0n) {
        console.log(`[Bot ${this.id}] No active stake found. Staking is required.`);
        // In a real implementation, you would call the staking function here
      }
      
      return { amount, lockEnd };
    } catch (error) {
      console.error(`[Bot ${this.id}] Error checking staking status:`, error.message);
      throw error;
    }
  }
  
  async checkPortfolio() {
    try {
      console.log(`[Bot ${this.id}] Checking portfolio...`);
      const [assets, weights, totalValue] = await this.portfolio.getPortfolioDetails();
      
      console.log(`[Bot ${this.id}] Current Portfolio (${ethers.formatEther(totalValue)} TVL):`);
      assets.forEach((asset, i) => {
        console.log(`  - ${asset}: ${weights[i] / 100}%`);
      });
      
      return { assets, weights, totalValue };
    } catch (error) {
      console.error(`[Bot ${this.id}] Error checking portfolio:`, error.message);
      throw error;
    }
  }
  
  async executeStrategy() {
    console.log(`[Bot ${this.id}] Executing ${this.strategy.name} strategy...`);
    
    try {
      // In a real implementation, this would contain the actual trading logic
      // based on the bot's strategy and market conditions
      
      // Example strategy implementation
      switch(this.strategy.name) {
        case 'conservative':
          await this.conservativeStrategy();
          break;
        case 'balanced':
          await this.balancedStrategy();
          break;
        case 'aggressive':
          await this.aggressiveStrategy();
          break;
        case 'arbitrage':
          await this.arbitrageStrategy();
          break;
        case 'market_maker':
          await this.marketMakerStrategy();
          break;
        default:
          console.log(`[Bot ${this.id}] Unknown strategy: ${this.strategy.name}`);
      }
      
      this.lastAction = new Date();
      console.log(`[Bot ${this.id}] Strategy execution completed at ${this.lastAction}`);
    } catch (error) {
      console.error(`[Bot ${this.id}] Error executing strategy:`, error.message);
    }
  }
  
  // Strategy implementations (simplified examples)
  async conservativeStrategy() {
    console.log(`[Bot ${this.id}] Running conservative strategy`);
    // Implement conservative trading logic
  }
  
  async balancedStrategy() {
    console.log(`[Bot ${this.id}] Running balanced strategy`);
    // Implement balanced trading logic
  }
  
  async aggressiveStrategy() {
    console.log(`[Bot ${this.id}] Running aggressive strategy`);
    // Implement aggressive trading logic
  }
  
  async arbitrageStrategy() {
    console.log(`[Bot ${this.id}] Running arbitrage strategy`);
    // Implement arbitrage logic
  }
  
  async marketMakerStrategy() {
    console.log(`[Bot ${this.id}] Running market maker strategy`);
    // Implement market making logic
  }
  
  async runLoop() {
    if (!this.isRunning) return;
    
    try {
      console.log(`\n[Bot ${this.id}] Running strategy cycle at ${new Date().toISOString()}`);
      await this.executeStrategy();
    } catch (error) {
      console.error(`[Bot ${this.id}] Error in run loop:`, error.message);
    }
  }
}

// Bot Manager to handle multiple bots
class BotManager {
  constructor() {
    this.bots = [];
    this.initializeBots();
  }
  
  initializeBots() {
    // Create bots based on configuration
    for (let i = 0; i < Math.min(config.BOTS.COUNT, config.BOTS.STRATEGIES.length); i++) {
      const bot = new TradingBot(i + 1, config.BOTS.STRATEGIES[i]);
      this.bots.push(bot);
    }
    
    // Set up graceful shutdown
    process.on('SIGINT', () => this.shutdown());
    process.on('SIGTERM', () => this.shutdown());
  }
  
  async startAll() {
    console.log('Starting all trading bots...');
    for (const bot of this.bots) {
      await bot.start();
      // Add a small delay between bot starts
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    console.log('All trading bots are running');
  }
  
  shutdown() {
    console.log('\nShutting down all trading bots...');
    this.bots.forEach(bot => bot.stop());
    console.log('All trading bots have been stopped');
    process.exit(0);
  }
}

// Main execution
async function main() {
  try {
    console.log('=== Pollen Trading Bots ===');
    console.log(`Network: ${config.RPC_URL}`);
    console.log(`Number of bots: ${config.BOTS.COUNT}`);
    
    // Initialize and start all bots
    const manager = new BotManager();
    await manager.startAll();
    
  } catch (error) {
    console.error('Error in main execution:', error);
    process.exit(1);
  }
}

// Run the script
main();
