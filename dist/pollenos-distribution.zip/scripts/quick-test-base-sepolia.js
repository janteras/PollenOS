require('dotenv').config({ path: require('path').resolve(__dirname, '../base-sepolia.env') });
const { ethers } = require('ethers');
const winston = require('winston');
const config = require('./config');

// Simple logger setup
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ level, message, timestamp }) => {
      return `${timestamp} [${level.toUpperCase()}]: ${message}`;
    })
  ),
  transports: [new winston.transports.Console()]
});

// Test configuration
const TEST_CONFIG = {
  maxFeePerGas: ethers.parseUnits('0.5', 'gwei'),
  maxPriorityFeePerGas: ethers.parseUnits('0.1', 'gwei'),
  testTimeout: 120000 // 2 minutes
};

class BaseSepoliaTester {
  constructor() {
    this.provider = new ethers.JsonRpcProvider(config.RPC_URL);
    const privateKey = process.env.WALLET_PRIVATE_KEY.startsWith('0x') 
      ? process.env.WALLET_PRIVATE_KEY 
      : '0x' + process.env.WALLET_PRIVATE_KEY;
    this.wallet = new ethers.Wallet(privateKey, this.provider);
    this.initializeContracts();
  }

  initializeContracts() {
    // Basic contract ABI with methods we've seen in the transaction history
    const contractABI = [
      'function balanceOf(address) view returns (uint256)',
      'function mint()',
      'function getCommunityCards()',
      'function startGame()',
      'function declareWinner()',
      'function hardReset()'
    ];

    this.contract = new ethers.Contract(
      config.CONTRACTS.VEPLN, // Using VEPLN as the main contract
      contractABI,
      this.wallet
    );
  }

  async runTests() {
    logger.info('🚀 Starting Base Sepolia Quick Tests');
    
    try {
      // Test 1: Network and Wallet
      await this.testNetworkConnectivity();
      
      // Test 2: Basic Contract Interaction
      await this.testBasicInteraction();
      
      logger.info('✅ All tests completed successfully');
    } catch (error) {
      logger.error('❌ Test failed:', error);
      throw error;
    }
  }

  async testNetworkConnectivity() {
    logger.info('\n=== 🔌 Testing Network Connectivity ===');
    const network = await this.provider.getNetwork();
    logger.info(`Connected to: ${network.name} (Chain ID: ${network.chainId})`);
    logger.info(`Using wallet: ${this.wallet.address}`);
    
    const ethBalance = await this.provider.getBalance(this.wallet.address);
    logger.info(`ETH Balance: ${ethers.formatEther(ethBalance)} ETH`);
    
    if (ethBalance < ethers.parseEther('0.01')) {
      throw new Error('Insufficient ETH for gas fees');
    }
  }

  async testBasicInteraction() {
    logger.info('\n=== 🔄 Testing Basic Contract Interaction ===');
    
    // Test balance check
    try {
      const balance = await this.contract.balanceOf(this.wallet.address);
      logger.info(`Contract balance: ${balance.toString()} tokens`);
    } catch (error) {
      logger.warn('Could not get balance:', error.message);
    }
    
    // Test mint function if balance is zero
    try {
      logger.info('Attempting to mint...');
      const tx = await this.contract.mint({
        maxFeePerGas: TEST_CONFIG.maxFeePerGas,
        maxPriorityFeePerGas: TEST_CONFIG.maxPriorityFeePerGas
      });
      const receipt = await tx.wait();
      logger.info(`✅ Mint successful in block ${receipt.blockNumber}`);
    } catch (error) {
      logger.warn('Mint failed or not available:', error.message);
    }
    
    // Test game functions
    await this.testGameFunctions();
  }

  async testGameFunctions() {
    logger.info('\n=== 🎮 Testing Game Functions ===');
    
    try {
      // Test start game
      const startTx = await this.contract.startGame({
        maxFeePerGas: TEST_CONFIG.maxFeePerGas,
        maxPriorityFeePerGas: TEST_CONFIG.maxPriorityFeePerGas
      });
      const startReceipt = await startTx.wait();
      logger.info(`✅ Start game successful in block ${startReceipt.blockNumber}`);
    } catch (error) {
      logger.warn('Start game failed or not available:', error.message);
    }
    
    try {
      // Test get community cards
      const cardsTx = await this.contract.getCommunityCards({
        maxFeePerGas: TEST_CONFIG.maxFeePerGas,
        maxPriorityFeePerGas: TEST_CONFIG.maxPriorityFeePerGas
      });
      const cardsReceipt = await cardsTx.wait();
      logger.info(`✅ Get community cards successful in block ${cardsReceipt.blockNumber}`);
    } catch (error) {
      logger.warn('Get community cards failed or not available:', error.message);
    }
  }
}

// Run the tests
async function main() {
  const tester = new BaseSepoliaTester();
  
  // Set timeout
  const timeout = setTimeout(() => {
    logger.error('Test timeout reached. Exiting...');
    process.exit(1);
  }, TEST_CONFIG.testTimeout);
  
  try {
    await tester.runTests();
    clearTimeout(timeout);
    process.exit(0);
  } catch (error) {
    console.error('Test error:', error);
    clearTimeout(timeout);
    process.exit(1);
  }
}

main().catch(console.error);
