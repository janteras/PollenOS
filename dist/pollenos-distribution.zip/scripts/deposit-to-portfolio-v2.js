require('dotenv').config({ path: require('path').resolve(__dirname, '.wallets') });
const { ethers } = require('ethers');
const { CONFIG } = require('./view-portfolio-details');

// Load private keys from environment variables
const PRIVATE_KEYS = [
  process.env.PRIVATE_KEY_1,
  process.env.PRIVATE_KEY_2,
  process.env.PRIVATE_KEY_3,
  process.env.PRIVATE_KEY_4,
  process.env.PRIVATE_KEY_5
].filter(Boolean);

// Deposit configuration
const DEPOSIT_CONFIG = {
  amount: '1', // 1 PLN per wallet
  gasLimit: 500000, // Increased gas limit
  gasPrice: ethers.utils.parseUnits('2', 'gwei'), // Explicit gas price
  delayBetweenWallets: 10000, // 10 seconds between wallets
  delayAfterApproval: 5000, // 5 seconds after approval
};

// Add delay helper
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function depositToPortfolio() {
  console.log('=== Starting Portfolio Deposit Process ===');
  console.log(`Processing ${PRIVATE_KEYS.length} wallets...\n`);

  const provider = new ethers.providers.JsonRpcProvider(CONFIG.RPC_URL, {
    name: 'base-sepolia',
    chainId: 84532,
  });

  // ABI for the Portfolio contract
  const portfolioABI = [
    'function depositPLN(uint256 amount, address recipient)',
    'function balanceOf(address) view returns (uint256)'
  ];

  for (const [index, privateKey] of PRIVATE_KEYS.entries()) {
    const wallet = new ethers.Wallet(privateKey, provider);
    console.log(`\n=== Processing Wallet ${index + 1}/${PRIVATE_KEYS.length} ===`);
    console.log(`Address: ${wallet.address}`);

    try {
      // 1. Check ETH balance first
      const ethBalance = await provider.getBalance(wallet.address);
      console.log(`   ETH Balance: ${ethers.utils.formatEther(ethBalance)}`);

      if (ethBalance.lt(ethers.utils.parseEther('0.01'))) {
        console.log('   ❌ Insufficient ETH for gas');
        continue;
      }

      // 2. Initialize PLN token contract
      const plnToken = new ethers.Contract(
        CONFIG.CONTRACTS.PLN,
        [
          'function balanceOf(address) view returns (uint256)',
          'function allowance(address,address) view returns (uint256)',
          'function approve(address,uint256) returns (bool)'
        ],
        wallet
      );

      // 3. Check PLN balance
      const plnBalance = await plnToken.balanceOf(wallet.address);
      const amountWei = ethers.utils.parseEther(DEPOSIT_CONFIG.amount);
      console.log(`   PLN Balance: ${ethers.utils.formatEther(plnBalance)}`);

      if (plnBalance.lt(amountWei)) {
        console.log(`   ❌ Insufficient PLN balance (needed: ${DEPOSIT_CONFIG.amount} PLN)`);
        continue;
      }

      // 4. Check and set allowance
      const allowance = await plnToken.allowance(wallet.address, CONFIG.CONTRACTS.PORTFOLIO);
      
      if (allowance.lt(amountWei)) {
        console.log('   Setting PLN allowance...');
        try {
          const approveTx = await plnToken.approve(
            CONFIG.CONTRACTS.PORTFOLIO,
            amountWei,
            {
              gasLimit: 250000,
              gasPrice: DEPOSIT_CONFIG.gasPrice
            }
          );
          
          console.log(`   ✅ Approval sent: ${approveTx.hash}`);
          console.log('   Waiting for confirmation...');
          
          const receipt = await approveTx.wait();
          console.log(`   ✅ Approval confirmed in block ${receipt.blockNumber}`);
          
          // Wait after approval
          console.log(`   Waiting ${DEPOSIT_CONFIG.delayAfterApproval/1000} seconds before deposit...`);
          await delay(DEPOSIT_CONFIG.delayAfterApproval);
        } catch (error) {
          console.error('   ❌ Approval failed:', error.message);
          if (error.transactionHash) {
            console.log(`   Transaction hash: ${error.transactionHash}`);
          }
          continue;
        }
      } else {
        console.log('   ✅ Sufficient allowance already set');
      }

      // 5. Initialize Portfolio contract
      const portfolio = new ethers.Contract(
        CONFIG.CONTRACTS.PORTFOLIO,
        portfolioABI,
        wallet
      );

      // 6. Make deposit
      console.log('   Sending deposit transaction...');
      try {
        const tx = await portfolio.depositPLN(
          amountWei,
          wallet.address, // recipient (self)
          {
            gasLimit: DEPOSIT_CONFIG.gasLimit,
            gasPrice: DEPOSIT_CONFIG.gasPrice
          }
        );

        console.log(`   ✅ Deposit sent: ${tx.hash}`);
        console.log('   Waiting for confirmation...');
        
        const receipt = await tx.wait();
        console.log(`   ✅ Deposit confirmed in block ${receipt.blockNumber}`);
        console.log(`   Transaction hash: ${receipt.transactionHash}`);
        console.log(`   Gas used: ${receipt.gasUsed.toString()}`);
        
      } catch (error) {
        console.error('   ❌ Deposit failed:', error.message);
        if (error.transactionHash) {
          console.log(`   Transaction hash: ${error.transactionHash}`);
          console.log(`   Check status: https://sepolia.basescan.org/tx/${error.transactionHash}`);
        }
        continue;
      }

      // Add delay between wallets if not the last one
      if (index < PRIVATE_KEYS.length - 1) {
        console.log(`\nWaiting ${DEPOSIT_CONFIG.delayBetweenWallets/1000} seconds before next wallet...`);
        await delay(DEPOSIT_CONFIG.delayBetweenWallets);
      }

    } catch (error) {
      console.error(`   ❌ Unexpected error: ${error.message}`);
      console.error('   Stack:', error.stack);
    }
  }

  console.log('\n=== Deposit Process Completed ===');
}

// Run with error handling
depositToPortfolio()
  .then(() => process.exit(0))
  .catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
  });
