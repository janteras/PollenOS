const { ethers } = require('ethers');
const config = require('./config');
const PollenDAOABI = require('../reference-code/pollen-subgraph-v3/abis/IPollenDAO.json');
const PollenTokenABI = require('../reference-code/pollen-subgraph-v3/abis/PollenToken.json');
// Import the getWhitelistedAssets function
const getWhitelistedAssets = require('./get-whitelisted-assets');

async function createPortfolio() {
  try {
    // Initialize provider and wallet
    const provider = new ethers.providers.JsonRpcProvider(config.RPC_URL);
    const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
    
    console.log('🔑 Wallet:', wallet.address);
    
    // Contract instances
    const dao = new ethers.Contract(config.CONTRACTS.POLLEN_DAO, PollenDAOABI, wallet);
    const plnToken = new ethers.Contract(config.CONTRACTS.PLN, PollenTokenABI, wallet);
    
    // Get whitelisted assets
    console.log('\n🔍 Fetching whitelisted assets...');
    const assets = await getWhitelistedAssets();
    
    if (!assets || assets.length === 0) {
      throw new Error('No whitelisted assets found. Cannot create portfolio.');
    }
    
    console.log(`\n✅ Found ${assets.length} whitelisted assets`);
    
    // Check PLN balance
    const balance = await plnToken.balanceOf(wallet.address);
    console.log(`💰 PLN Balance: ${ethers.utils.formatEther(balance)} PLN`);
    
    if (balance.eq(0)) {
      throw new Error('Insufficient PLN balance');
    }
    
    // Portfolio parameters
    const amount = ethers.utils.parseEther('10'); // 10 PLN
    
    // Calculate equal weights for all assets (each weight is a percentage, total should be 100)
    const weightPerAsset = Math.floor(100 / assets.length);
    const weights = Array(assets.length).fill(weightPerAsset);
    
    // Adjust the first weight to ensure the total is exactly 100
    const totalWeight = weights.reduce((sum, w) => sum + w, 0);
    if (totalWeight < 100) {
      weights[0] += (100 - totalWeight);
    }
    
    // By default, we're not shorting any assets
    const isShort = Array(assets.length).fill(false);
    const tokenType = false; // false for PLN, true for vePLN
    
    console.log('\n📋 Portfolio Parameters:');
    console.log(`- Amount: ${ethers.utils.formatEther(amount)} PLN`);
    console.log(`- Number of Assets: ${assets.length}`);
    console.log(`- Weights: [${weights.map(w => w/100).join('%, ')}%] (Total: ${weights.reduce((a, b) => a + b, 0)/100}%)`);
    console.log(`- Is Short: [${isShort.join(', ')}]`);
    console.log(`- Token Type: ${tokenType ? 'vePLN' : 'PLN'}`);
    
    // Check allowance and approve if needed
    const allowance = await plnToken.allowance(wallet.address, config.CONTRACTS.POLLEN_DAO);
    
    if (allowance.lt(amount)) {
      console.log('\n🔏 Approving PLN tokens for PollenDAO...');
      const approveTx = await plnToken.approve(config.CONTRACTS.POLLEN_DAO, amount);
      await approveTx.wait();
      console.log('✅ Approval confirmed');
    }
    
    // Create portfolio
    console.log('\n🚀 Creating portfolio...');
    const tx = await dao.createPortfolio(amount, weights, isShort, tokenType);
    console.log('⏳ Waiting for transaction confirmation...');
    
    const receipt = await tx.wait();
    console.log('✅ Portfolio created successfully!');
    console.log('Transaction hash:', receipt.transactionHash);
    
    // Look for PortfolioCreated event in the receipt
    const event = receipt.events?.find(e => e.event === 'PortfolioCreated');
    if (event) {
      console.log('\n🎉 Portfolio Created Event:');
      console.log('- Owner:', event.args.owner);
      console.log('- Portfolio Address:', event.args.portfolio);
      console.log('- Amount:', ethers.utils.formatEther(event.args.amount.toString()));
      
      // Save the portfolio address to config
      if (event.args.portfolio) {
        // Update config in memory
        config.CONTRACTS.PORTFOLIO = event.args.portfolio;
        console.log('\n💾 Updated config with new portfolio address:', event.args.portfolio);
      }
    }
    
  } catch (error) {
    console.error('❌ Error creating portfolio:', error);
    if (error.data) {
      console.error('Error data:', error.data);
    }
    if (error.reason) {
      console.error('Reason:', error.reason);
    }
  }
}

// Run the function
if (require.main === module) {
  createPortfolio().catch(console.error);
}

module.exports = createPortfolio;
