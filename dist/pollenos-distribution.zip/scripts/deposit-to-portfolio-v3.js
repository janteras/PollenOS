require('dotenv').config({ path: require('path').resolve(__dirname, '.wallets') });
const { ethers } = require('ethers');
const { CONFIG } = require('./view-portfolio-details');

// Load private keys from environment variables
const PRIVATE_KEYS = [
  process.env.PRIVATE_KEY_1,
  process.env.PRIVATE_KEY_2,
  process.env.PRIVATE_KEY_3,
  process.env.PRIVATE_KEY_4,
  process.env.PRIVATE_KEY_5
].filter(Boolean);

// Portfolio configuration
const PORTFOLIO_CONFIG = {
  // Long position configuration (safer for initial testing)
  longPosition: {
    name: 'Long Position',
    weights: [20, 20, 20, 20, 10, 5, 5], // Must sum to 100
    isShort: [false, false, false, false, false, false, false],
    tokenType: false // PLN
  },
  // Short position configuration (more aggressive)
  shortPosition: {
    name: 'Short Position',
    weights: [30, 25, 20, 15, 5, 3, 2], // Must sum to 100
    isShort: [true, true, true, true, true, true, true],
    tokenType: true // vePLN
  }
};

// Deposit configuration
const DEPOSIT_CONFIG = {
  amount: '1', // 1 PLN per wallet
  gasLimit: 2000000, // Increased gas limit for portfolio creation
  gasPrice: ethers.utils.parseUnits('2', 'gwei'), // Explicit gas price
  delayBetweenWallets: 10000, // 10 seconds between wallets
  delayAfterApproval: 5000, // 5 seconds after approval
  positionType: 'long' // 'long' or 'short'
};

// Add delay helper
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

// ABI for the Portfolio contract
const PORTFOLIO_ABI = [
  'function depositPLN(uint256 amount, address recipient)',
  'function createPortfolio(uint256 amount, uint256[] calldata weights, bool[] calldata isShort, bool tokenType)',
  'function getPortfolio(address user, address token) view returns (uint256[], uint256, uint256, uint256, bool, uint256, uint256, bool[])',
  'function balanceOf(address) view returns (uint256)',
  'event PortfolioCreated(address indexed user, address indexed token, uint256 amount, uint256[] weights, bool[] isShort, bool tokenType)'
];

// ABI for the PLN token
const ERC20_ABI = [
  'function balanceOf(address) view returns (uint256)',
  'function allowance(address, address) view returns (uint256)',
  'function approve(address, uint256) returns (bool)',
  'function decimals() view returns (uint8)'
];

class PortfolioManager {
  constructor(wallet, provider) {
    this.wallet = wallet;
    this.provider = provider;
    this.plnToken = new ethers.Contract(
      CONFIG.CONTRACTS.PLN,
      ERC20_ABI,
      wallet
    );
    this.portfolio = new ethers.Contract(
      CONFIG.CONTRACTS.PORTFOLIO,
      PORTFOLIO_ABI,
      wallet
    );
    this.plnDecimals = null;
  }

  async initialize() {
    this.plnDecimals = await this.plnToken.decimals();
    console.log(`   Initialized for wallet: ${this.wallet.address}`);
    return this;
  }

  async checkBalances() {
    const ethBalance = await this.wallet.getBalance();
    const plnBalance = await this.plnToken.balanceOf(this.wallet.address);
    
    console.log('   Balances:', {
      ETH: ethers.utils.formatEther(ethBalance),
      PLN: ethers.utils.formatUnits(plnBalance, this.plnDecimals)
    });

    return { ethBalance, plnBalance };
  }

  async ensureApproval(amountWei) {
    const allowance = await this.plnToken.allowance(
      this.wallet.address,
      CONFIG.CONTRACTS.PORTFOLIO
    );

    if (allowance.lt(amountWei)) {
      console.log(`   Approving ${ethers.utils.formatUnits(amountWei, this.plnDecimals)} PLN...`);
      const approveTx = await this.plnToken.approve(
        CONFIG.CONTRACTS.PORTFOLIO,
        amountWei,
        { 
          gasLimit: 250000,
          gasPrice: DEPOSIT_CONFIG.gasPrice
        }
      );
      
      console.log(`   ✅ Approval sent: ${approveTx.hash}`);
      console.log('   Waiting for confirmation...');
      
      const receipt = await approveTx.wait();
      console.log(`   ✅ Approval confirmed in block ${receipt.blockNumber}`);
      
      // Wait after approval
      console.log(`   Waiting ${DEPOSIT_CONFIG.delayAfterApproval/1000} seconds before next step...`);
      await delay(DEPOSIT_CONFIG.delayAfterApproval);
    } else {
      console.log('   ✅ Sufficient allowance already set');
    }
  }

  async createPortfolio(amountWei, position) {
    console.log(`   Creating ${position.name}...`);
    
    try {
      const tx = await this.portfolio.createPortfolio(
        amountWei,
        position.weights,
        position.isShort,
        position.tokenType,
        {
          gasLimit: DEPOSIT_CONFIG.gasLimit,
          gasPrice: DEPOSIT_CONFIG.gasPrice
        }
      );
      
      console.log(`   ✅ Portfolio creation tx: ${tx.hash}`);
      console.log('   Waiting for confirmation...');
      
      const receipt = await tx.wait();
      console.log(`   ✅ Portfolio created in block ${receipt.blockNumber}`);
      
      // Wait a bit after creation
      await delay(2000);
      return true;
    } catch (error) {
      console.error('   ❌ Portfolio creation failed:', error.message);
      if (error.transactionHash) {
        console.log(`   Transaction hash: ${error.transactionHash}`);
      }
      return false;
    }
  }

  async deposit(amountWei) {
    console.log('   Sending deposit transaction...');
    
    try {
      const tx = await this.portfolio.depositPLN(
        amountWei,
        this.wallet.address, // recipient (self)
        {
          gasLimit: DEPOSIT_CONFIG.gasLimit,
          gasPrice: DEPOSIT_CONFIG.gasPrice
        }
      );

      console.log(`   ✅ Deposit sent: ${tx.hash}`);
      console.log('   Waiting for confirmation...');
      
      const receipt = await tx.wait();
      console.log(`   ✅ Deposit confirmed in block ${receipt.blockNumber}`);
      console.log(`   Gas used: ${receipt.gasUsed.toString()}`);
      
      return true;
    } catch (error) {
      console.error('   ❌ Deposit failed:', error.message);
      if (error.transactionHash) {
        console.log(`   Transaction hash: ${error.transactionHash}`);
      }
      return false;
    }
  }

  async checkPortfolio() {
    try {
      const portfolioData = await this.portfolio.getPortfolio(
        this.wallet.address,
        ethers.constants.AddressZero
      );
      
      const portfolioInfo = {
        exists: true,
        isActive: portfolioData[4],
        totalValue: ethers.utils.formatUnits(portfolioData[1], this.plnDecimals),
        weights: portfolioData[0].map(w => w.toString()),
        isShort: portfolioData[7] || []
      };
      
      console.log('   Portfolio Info:', {
        exists: true,
        isActive: portfolioInfo.isActive,
        totalValue: `${portfolioInfo.totalValue} PLN`,
        weights: portfolioInfo.weights
      });
      
      return portfolioInfo;
    } catch (error) {
      if (error.reason === 'Portfolio does not exist') {
        console.log('   No portfolio exists for this wallet');
        return { exists: false };
      }
      console.error('   ❌ Error checking portfolio:', error.message);
      throw error;
    }
  }
}

async function depositToPortfolio() {
  console.log('=== Starting Enhanced Portfolio Deposit Process ===');
  console.log(`Processing ${PRIVATE_KEYS.length} wallets...\n`);
  console.log(`Using ${DEPOSIT_CONFIG.positionType} position type\n`);

  const provider = new ethers.providers.JsonRpcProvider(CONFIG.RPC_URL, {
    name: 'base-sepolia',
    chainId: 84532,
  });

  // Select position type
  const position = DEPOSIT_CONFIG.positionType === 'short' 
    ? PORTFOLIO_CONFIG.shortPosition 
    : PORTFOLIO_CONFIG.longPosition;

  for (const [index, privateKey] of PRIVATE_KEYS.entries()) {
    console.log(`\n=== Processing Wallet ${index + 1}/${PRIVATE_KEYS.length} ===`);
    
    try {
      const wallet = new ethers.Wallet(privateKey, provider);
      console.log(`Address: ${wallet.address}`);
      
      // Initialize portfolio manager
      const manager = await new PortfolioManager(wallet, provider).initialize();
      
      // 1. Check balances
      const { ethBalance, plnBalance } = await manager.checkBalances();
      const amountWei = ethers.utils.parseUnits(DEPOSIT_CONFIG.amount, await manager.plnToken.decimals());

      // Check if we have enough ETH for gas
      if (ethBalance.lt(ethers.utils.parseEther('0.01'))) {
        console.log('   ❌ Insufficient ETH for gas');
        continue;
      }

      // Check if we have enough PLN
      if (plnBalance.lt(amountWei)) {
        console.log(`   ❌ Insufficient PLN balance (needed: ${DEPOSIT_CONFIG.amount} PLN)`);
        continue;
      }
      
      // 2. Check portfolio status
      const portfolio = await manager.checkPortfolio();
      
      // 3. Ensure allowance
      await manager.ensureApproval(amountWei);
      
      // 4. Create portfolio if it doesn't exist
      if (!portfolio.exists) {
        console.log('   No portfolio found, creating one...');
        const created = await manager.createPortfolio(amountWei, position);
        if (!created) continue;
      } else {
        console.log('   Using existing portfolio');
      }
      
      // 5. Make deposit
      await manager.deposit(amountWei);
      
      // 6. Verify final state
      await manager.checkPortfolio();
      
      console.log(`   ✅ Successfully processed wallet ${index + 1}`);
      
      // Add delay between wallets if not the last one
      if (index < PRIVATE_KEYS.length - 1) {
        console.log(`\nWaiting ${DEPOSIT_CONFIG.delayBetweenWallets/1000} seconds before next wallet...`);
        await delay(DEPOSIT_CONFIG.delayBetweenWallets);
      }
      
    } catch (error) {
      console.error(`   ❌ Error processing wallet: ${error.message}`);
      if (error.transactionHash) {
        console.log(`   Transaction hash: ${error.transactionHash}`);
      }
      continue;
    }
  }

  console.log('\n=== Deposit Process Completed ===');
}

// Run with error handling
depositToPortfolio()
  .then(() => process.exit(0))
  .catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
  });
