require('dotenv').config({ path: require('path').resolve(__dirname, '.wallets') });
const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');
const CONFIG = require('./config');

// ERC20 ABI
const ERC20_ABI = [
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function decimals() view returns (uint8)',
  'function totalSupply() view returns (uint256)',
  'function balanceOf(address) view returns (uint256)',
  'function transfer(address to, uint256 amount) returns (bool)',
  'function approve(address spender, uint256 amount) returns (bool)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function transferFrom(address from, address to, uint256 amount) returns (bool)'
];

// Contract ABIs
const PORTFOLIO_ABI = [
  'function depositPLN(uint256 amount, address recipient)',
  'function createPortfolio(uint256 amount, uint256[] calldata weights, bool[] calldata isShort, bool tokenType)',
  'function getPortfolio(address user, address token) view returns (uint256[] memory, uint256, uint256, uint256, bool, uint256, uint256, bool[] memory)',
  'function getPortfolioValue(address user, address token) view returns (uint256)',
  'function getPortfolioState(address user) view returns (uint256 totalValue, uint256 depositPLN, uint256 depositVePLN, uint256 withdrawn, bool isActive, uint256 timestamp, uint256 benchMarkRef, uint256 lastRebalanceTime)',
  'function getWhitelistedAssets() view returns (address[] memory)',
  'function getAssetCount() view returns (uint256)',
  'function rebalance(uint256[] calldata newWeights, bool[] calldata newIsShort)',
  'function withdraw(uint256 amount, address recipient)'
];

const FUNDED_WALLETS = [
  {
    address: '0x171ba64eeD23045486C1B47FB209A49d0894562f',
    privateKey: '0xbc8b385d2975654c2502033499570d48218b18afa5409a696d2a0c37fab0a42a'
  },
  {
    address: '0xfA36aEd12D913498A4b6C7Ef3a28C5659B8119f3',
    privateKey: '0x2d4c8ba78a103098d4a0d0aee78a690d5122a33c426c924abdc12e30a9df876d'
  }
];

// Default portfolio configuration
const DEFAULT_WEIGHTS = [9000, 1000]; // 90% first asset, 10% second asset
const DEFAULT_IS_SHORT = [false, false]; // Both positions are long
const TOKEN_TYPE = false; // false for PLN, true for vePLN

// Create a PortfolioTester factory function instead of a class
function createPortfolioTester(wallet, provider, contractAddresses) {
  // Default contract addresses if not provided
  const defaultAddresses = {
    portfolio: '0x0000000000000000000000000000000000000000',
    plnToken: '0x0000000000000000000000000000000000000000',
    quoter: '0x0000000000000000000000000000000000000000'
  };
  
  // Merge with provided addresses
  const contracts = { ...defaultAddresses, ...contractAddresses };
  
  // Contract ABIs - include all necessary functions
  const portfolioABI = [
    'function createPortfolio(uint256,uint256[],bool[],bool) external',
    'function depositPLN(uint256 amount, address recipient)',
    'function getPortfolio(address,address) external view returns (uint256[],uint256,uint256,uint256,bool,uint256,uint256,bool[])',
    'function rebalance(uint256[] calldata newWeights, bool[] calldata newIsShort)',
    'function withdraw(uint256 amount, address recipient)',
    'function getPortfolioValue(address user, address token) view returns (uint256)',
    'function getWhitelistedAssets() view returns (address[] memory)',
    'function getAssetCount() view returns (uint256)'
  ];
  
  // Create contract instances
  const portfolio = new ethers.Contract(contracts.portfolio, portfolioABI, wallet);
  const plnToken = new ethers.Contract(contracts.plnToken, ERC20_ABI, wallet);
  
  // Initialize state
  let plnDecimals = 18;
  
  // Define methods
  const tester = {
    async initialize() {
      try {
        // Fetch token decimals
        plnDecimals = await plnToken.decimals();
        console.log(`PLN Token Decimals: ${plnDecimals}`);
        
        // Log contract addresses
        console.log('Using contracts:');
        console.log(`- Portfolio: ${contracts.portfolio}`);
        console.log(`- PLN Token: ${contracts.plnToken}`);
        console.log(`- Quoter: ${contracts.quoter}`);
        
        return true;
      } catch (error) {
        console.error('Failed to initialize PortfolioTester:', error);
        return false;
      }
    },
    
    async logBalances() {
      try {
        const [ethBalance, plnBalance, plnAllowance] = await Promise.all([
          wallet.getBalance(),
          plnToken.balanceOf(wallet.address),
          plnToken.allowance(wallet.address, contracts.portfolio)
        ]);
        
        console.log('\n💰 Balances:');
        console.log(`- ETH:      ${ethers.utils.formatEther(ethBalance)}`);
        console.log(`- PLN:      ${ethers.utils.formatUnits(plnBalance, plnDecimals)}`);
        console.log(`- Allowance: ${ethers.utils.formatUnits(plnAllowance, plnDecimals)} PLN`);
        
        return { ethBalance, plnBalance, plnAllowance };
      } catch (error) {
        console.error('Error getting balances:', error);
        throw error;
      }
    }
  };
  
  // Add other methods as needed
  
  // Initialize method
  tester.initialize = async () => {
    try {
      // Fetch token decimals
      plnDecimals = await plnToken.decimals();
      console.log(`PLN Token Decimals: ${plnDecimals}`);
      
      // Log contract addresses
      console.log('Using contracts:');
      console.log(`- Portfolio: ${contracts.portfolio}`);
      console.log(`- PLN Token: ${contracts.plnToken}`);
      console.log(`- Quoter: ${contracts.quoter}`);
      
      return true;
    } catch (error) {
      console.error('Failed to initialize PortfolioTester:', error);
      return false;
    }
  };
  
  // Add checkPortfolioExists method
  tester.checkPortfolioExists = async () => {
    try {
      const portfolioData = await portfolio.getPortfolio(wallet.address, wallet.address);
      const [assetAmounts, balance, depositPLN, depositVePLN, isOpen, , , isShort] = portfolioData;
      const exists = assetAmounts.length > 0 || balance.gt(0) || depositPLN.gt(0) || depositVePLN.gt(0);
      
      return { 
        exists, 
        isOpen,
        details: {
          balance: ethers.utils.formatUnits(balance, plnDecimals),
          depositPLN: ethers.utils.formatUnits(depositPLN, plnDecimals),
          depositVePLN: ethers.utils.formatUnits(depositVePLN, plnDecimals),
          assetCount: assetAmounts.length,
          hasShortPositions: isShort.some(short => short)
        }
      };
    } catch (error) {
      if (error.message.includes('execution reverted')) {
        return { exists: false, isOpen: false, details: null };
      }
      throw error;
    }
  };
  
  // Add createPortfolio method
  tester.createPortfolio = async (depositAmount) => {
    try {
      console.log('\n🔄 Creating new portfolio...');
      
      // Get default weights and short positions
      const weights = await tester.getDefaultWeights();
      const isShort = await tester.getDefaultIsShort(weights);
      
      // Convert deposit amount to wei
      const depositAmountWei = ethers.utils.parseUnits(depositAmount.toString(), plnDecimals);
      
      // Create portfolio
      const tx = await portfolio.createPortfolio(
        depositAmountWei,
        weights,
        isShort,
        TOKEN_TYPE
      );
      
      console.log(`✅ Portfolio created. Transaction hash: ${tx.hash}`);
      
      // Wait for confirmation
      const receipt = await tx.wait();
      console.log(`✅ Transaction confirmed in block ${receipt.blockNumber}`);
      
      return {
        success: true,
        transactionHash: tx.hash,
        blockNumber: receipt.blockNumber
      };
    } catch (error) {
      console.error('❌ Error creating portfolio:', error.message);
      
      // Try to extract revert reason
      let revertReason = 'Unknown error';
      if (error.data) {
        try {
          const decoded = ethers.utils.defaultAbiCoder.decode(['string'], `0x${error.data.slice(10)}`);
          revertReason = decoded[0];
        } catch (e) {
          // If we can't decode the revert reason, use the original error
          revertReason = error.message;
        }
      }
      
      return {
        success: false,
        error: revertReason,
        transactionHash: error.transactionHash
      };
    }
  };
  
  // Add depositFunds method
  tester.depositFunds = async (amount, options = {}) => {
    const {
      createIfNotExists = true,
      autoApprove = true
    } = options;
    
    try {
      // Check if portfolio exists
      const portfolioCheck = await tester.checkPortfolioExists();
      
      if (!portfolioCheck.exists && createIfNotExists) {
        console.log('No portfolio found. Creating a new one...');
        const createResult = await tester.createPortfolio(amount);
        
        if (!createResult.success) {
          throw new Error(`Failed to create portfolio: ${createResult.error}`);
        }
        
        return {
          success: true,
          portfolioCreated: true,
          transactionHash: createResult.transactionHash
        };
      }
      
      if (!portfolioCheck.isOpen) {
        throw new Error('Portfolio exists but is not open');
      }
      
      // Convert amount to wei
      const amountWei = ethers.utils.parseUnits(amount.toString(), plnDecimals);
      
      // Check and approve tokens if needed
      if (autoApprove) {
        const allowance = await plnToken.allowance(wallet.address, contracts.portfolio);
        if (allowance.lt(amountWei)) {
          console.log('Approving tokens...');
          const approveTx = await plnToken.approve(contracts.portfolio, amountWei.mul(2)); // Approve 2x to reduce transactions
          await approveTx.wait();
        }
      }
      
      // Deposit funds
      console.log(`Depositing ${amount} PLN to portfolio...`);
      const tx = await portfolio.depositPLN(amountWei, wallet.address);
      
      console.log(`✅ Deposit initiated. Transaction hash: ${tx.hash}`);
      
      // Wait for confirmation
      const receipt = await tx.wait();
      console.log(`✅ Transaction confirmed in block ${receipt.blockNumber}`);
      
      return {
        success: true,
        portfolioCreated: false,
        transactionHash: tx.hash,
        blockNumber: receipt.blockNumber
      };
      
    } catch (error) {
      console.error('❌ Deposit failed:', error.message);
      
      // Try to extract revert reason
      let revertReason = error.message;
      if (error.data) {
        try {
          const decoded = ethers.utils.defaultAbiCoder.decode(['string'], `0x${error.data.slice(10)}`);
          revertReason = decoded[0];
        } catch (e) {
          // If we can't decode the revert reason, use the original error
          revertReason = error.message;
        }
      }
      
      return {
        success: false,
        error: revertReason,
        transactionHash: error.transactionHash
      };
    }
  };
  
    // Add rebalancePortfolio method with retry logic for gas price issues
  const MAX_RETRIES = 3;
  const BASE_GAS_PRICE_MULTIPLIER = 1.1; // 10% increase per retry
  
  tester.rebalancePortfolio = async (newWeights, newIsShort, retryCount = 0) => {
    try {
      console.log('\n🔄 Rebalancing portfolio...');
      
      // If no new weights provided, use default weights
      if (!newWeights) {
        newWeights = await tester.getDefaultWeights();
      }
      
      // If no new short positions provided, default to all long
      if (!newIsShort) {
        newIsShort = Array(newWeights.length).fill(false);
      }
      
      // Convert weights to basis points (1% = 100)
      const weightsInBasisPoints = newWeights.map(w => w * 100);
      
      // Ensure weights sum to 10000 (100% in basis points)
      const sumWeights = weightsInBasisPoints.reduce((a, b) => a + b, 0);
      if (sumWeights !== 10000) {
        console.warn(`⚠️ Weights sum to ${sumWeights/100}% instead of 100%. Adjusting last weight.`);
        weightsInBasisPoints[weightsInBasisPoints.length - 1] += (10000 - sumWeights);
      }
      
      console.log('New weights:', weightsInBasisPoints);
      console.log('New short positions:', newIsShort);
      
      // Get current gas price and apply multiplier for retries
      const baseGasPrice = await provider.getGasPrice();
      const gasPrice = baseGasPrice.mul(Math.floor(Math.pow(BASE_GAS_PRICE_MULTIPLIER, retryCount) * 100)).div(100);
      
      console.log(`Using gas price: ${ethers.utils.formatUnits(gasPrice, 'gwei')} gwei`);
      
      // Get the contract with signer for sending transactions
      const portfolioWithSigner = portfolio.connect(wallet);
      
      try {
        // Execute rebalance with higher gas limit and price
        const tx = await portfolioWithSigner.rebalance(
          weightsInBasisPoints,
          newIsShort,
          { 
            gasLimit: 1500000, // Set a higher gas limit for rebalance
            gasPrice: gasPrice
          }
        );
        
        console.log(`✅ Rebalance initiated. Transaction hash: ${tx.hash}`);
        const receipt = await tx.wait();
        console.log(`✅ Rebalance confirmed in block ${receipt.blockNumber}`);
        
        return {
          success: true,
          transactionHash: tx.hash,
          blockNumber: receipt.blockNumber
        };
      } catch (txError) {
        // Handle replacement fee too low error
        if ((txError.message.includes('replacement fee too low') || 
             txError.message.includes('nonce too low')) && 
            retryCount < MAX_RETRIES) {
          console.warn(`⚠️ Replacement fee too low, retrying (${retryCount + 1}/${MAX_RETRIES})...`);
          return tester.rebalancePortfolio(newWeights, newIsShort, retryCount + 1);
        }
        throw txError; // Re-throw if not a gas price issue or max retries reached
      }
      
    } catch (error) {
      let revertReason = 'Unknown error';
      if (error.data) {
        try {
          const decodedError = portfolio.interface.parseError(error.data);
          revertReason = decodedError.signature;
        } catch (e) {
          revertReason = error.reason || error.message;
        }
      } else {
        revertReason = error.reason || error.message;
      }
      
      console.error('❌ Error rebalancing portfolio:', revertReason);
      throw new Error(`Rebalance failed: ${revertReason}`);
    }
  };
  
  // Add depositPLN method with enhanced logging and error handling
  tester.depositPLN = async (amount, recipient = null) => {
    try {
      console.log(`\n💰 Depositing ${amount} PLN...`);
      
      // If no recipient specified, use wallet address
      if (!recipient) {
        recipient = wallet.address;
      }
      
      // Convert amount to wei and validate
      const amountWei = ethers.utils.parseUnits(amount.toString(), plnDecimals);
      if (amountWei.lte(0)) {
        throw new Error('Deposit amount must be greater than 0');
      }
      
      console.log(`Recipient: ${recipient}`);
      console.log(`Amount: ${amount} PLN (${amountWei.toString()} wei)`);
      
      // Check wallet balance
      const walletBalance = await plnToken.balanceOf(wallet.address);
      console.log(`Wallet balance: ${ethers.utils.formatUnits(walletBalance, plnDecimals)} PLN`);
      
      if (walletBalance.lt(amountWei)) {
        throw new Error(`Insufficient balance. Required: ${amount} PLN, Available: ${ethers.utils.formatUnits(walletBalance, plnDecimals)} PLN`);
      }
      
      // Check allowance and approve if needed
      const allowance = await plnToken.allowance(wallet.address, contracts.portfolio);
      console.log(`Current allowance: ${ethers.utils.formatUnits(allowance, plnDecimals)} PLN`);
      
      if (allowance.lt(amountWei)) {
        console.log('Approving PLN token spend...');
        const approveTx = await plnToken.approve(contracts.portfolio, amountWei);
        console.log(`Approval tx hash: ${approveTx.hash}`);
        const approveReceipt = await approveTx.wait();
        console.log(`Approval confirmed in block ${approveReceipt.blockNumber}`);
        
        // Verify new allowance
        const newAllowance = await plnToken.allowance(wallet.address, contracts.portfolio);
        console.log(`New allowance: ${ethers.utils.formatUnits(newAllowance, plnDecimals)} PLN`);
        
        if (newAllowance.lt(amountWei)) {
          throw new Error('Failed to set sufficient allowance');
        }
      }
      
      // Get current portfolio state with detailed logging
      console.log('\n📊 Current portfolio state before deposit:');
      const portfolioState = await portfolio.getPortfolio(wallet.address, contracts.plnToken);
      console.log(JSON.stringify({
        totalValue: ethers.utils.formatUnits(portfolioState[1], plnDecimals),
        depositPLN: ethers.utils.formatUnits(portfolioState[2], plnDecimals),
        depositPLNWei: portfolioState[2].toString(),
        isActive: portfolioState[4],
        rawState: portfolioState.map((val, idx) => ({
          index: idx,
          value: val.toString(),
          formatted: idx === 0 ? val : (idx <= 3 ? ethers.utils.formatUnits(val, plnDecimals) : val)
        }))
      }, null, 2));
      
      // Get the contract with signer for sending transactions
      const portfolioWithSigner = portfolio.connect(wallet);
      const gasPrice = await provider.getGasPrice();
      
      console.log('\n🚀 Sending deposit transaction...');
      console.log(`From: ${wallet.address}`);
      console.log(`To: ${contracts.portfolio}`);
      console.log(`Value: ${amountWei.toString()} wei`);
      console.log(`Gas Price: ${ethers.utils.formatUnits(gasPrice, 'gwei')} gwei`);
      
      // Execute deposit with error handling for revert reasons
      let tx, receipt;
      try {
        tx = await portfolioWithSigner.depositPLN(
          amountWei,
          recipient,
          { 
            gasLimit: 1000000, // Set a higher gas limit for deposit
            gasPrice: gasPrice
          }
        );
        
        console.log(`✅ Deposit transaction sent. Hash: ${tx.hash}`);
        receipt = await tx.wait();
        console.log(`✅ Deposit confirmed in block ${receipt.blockNumber}`);
        
        // Log all events from the receipt
        if (receipt.events && receipt.events.length > 0) {
          console.log('\n📝 Transaction events:');
          receipt.events.forEach((event, i) => {
            console.log(`  ${i + 1}. ${event.event || 'UnknownEvent'} (${event.eventSignature || 'no signature'})`);
            console.log(`     Args: ${JSON.stringify(event.args || {}, (_, v) => 
              typeof v === 'bigint' ? v.toString() : v, 2)}`);
          });
        } else {
          console.log('ℹ️  No events emitted in transaction');
        }
      } catch (error) {
        console.error('❌ Transaction failed:', error);
        if (error.transactionHash) {
          console.log(`Transaction hash: ${error.transactionHash}`);
          // Try to get the revert reason
          try {
            const tx = await provider.getTransaction(error.transactionHash);
            const code = await provider.call(tx, tx.blockNumber);
            const reason = ethers.utils.toUtf8String('0x' + code.substr(138));
            console.log(`Revert reason: ${reason}`);
          } catch (e) {
            console.log('Could not decode revert reason:', e.message);
          }
        }
        throw error;
      }
      
      // Get updated portfolio state with delay to ensure state is updated
      console.log('\n⏳ Waiting for state updates...');
      await new Promise(resolve => setTimeout(resolve, 5000)); // 5 second delay
      
      console.log('\n📊 Updated portfolio state after deposit:');
      const newState = await portfolio.getPortfolio(wallet.address, contracts.plnToken);
      console.log(JSON.stringify({
        totalValue: ethers.utils.formatUnits(newState[1], plnDecimals),
        depositPLN: ethers.utils.formatUnits(newState[2], plnDecimals),
        depositPLNWei: newState[2].toString(),
        isActive: newState[4],
        rawState: newState.map((val, idx) => ({
          index: idx,
          value: val.toString(),
          formatted: idx === 0 ? val : (idx <= 3 ? ethers.utils.formatUnits(val, plnDecimals) : val)
        }))
      }, null, 2));
      
      // Verify the deposit was successful
      const depositIncreased = newState[2].gt(portfolioState[2]);
      console.log(`\n🔍 Deposit verification: ${depositIncreased ? '✅ Success' : '❌ Failed'}`);
      if (!depositIncreased) {
        console.log('Warning: Deposit amount did not increase after transaction');
        console.log('Possible issues:');
        console.log('1. The transaction may have reverted without throwing an error');
        console.log('2. The depositPLN function may not be updating the state correctly');
        console.log('3. There might be an issue with the contract state management');
      }
      
      return {
        success: true,
        transactionHash: tx.hash,
        blockNumber: receipt.blockNumber,
        newState
      };
    } catch (error) {
      let revertReason = 'Unknown error';
      if (error.data) {
        try {
          const decodedError = portfolio.interface.parseError(error.data);
          revertReason = decodedError.signature;
        } catch (e) {
          revertReason = error.reason || error.message;
        }
      } else {
        revertReason = error.reason || error.message;
      }
      
      console.error('❌ Error depositing PLN:', revertReason);
      throw new Error(`Deposit failed: ${revertReason}`);
    }
  };
  
  // Add withdrawFunds method
  tester.withdrawFunds = async (amount, recipient = null) => {
    try {
      console.log(`\n💸 Withdrawing ${amount} PLN...`);
      
      // If no recipient specified, use wallet address
      if (!recipient) {
        recipient = wallet.address;
      }
      
      // Convert amount to wei
      const amountWei = ethers.utils.parseUnits(amount.toString(), plnDecimals);
      
      // Get current portfolio state using getPortfolio
      const portfolioState = await portfolio.getPortfolio(wallet.address, contracts.plnToken);
      console.log('Current portfolio state before withdrawal:', {
        totalValue: ethers.utils.formatUnits(portfolioState[1], plnDecimals),
        depositPLN: ethers.utils.formatUnits(portfolioState[2], plnDecimals),
        isActive: portfolioState[4]
      });
      
      // Get the contract with signer for sending transactions
      const portfolioWithSigner = portfolio.connect(wallet);
      
      // Execute withdrawal with a higher gas limit
      const tx = await portfolioWithSigner.withdraw(
        amountWei,
        recipient,
        { 
          gasLimit: 1000000, // Set a higher gas limit for withdrawal
          gasPrice: await provider.getGasPrice()
        }
      );
      
      console.log(`✅ Withdrawal initiated. Transaction hash: ${tx.hash}`);
      const receipt = await tx.wait();
      console.log(`✅ Withdrawal confirmed in block ${receipt.blockNumber}`);
      
      // Get updated portfolio state
      const newState = await portfolio.getPortfolio(wallet.address, contracts.plnToken);
      console.log('Updated portfolio state after withdrawal:', {
        totalValue: ethers.utils.formatUnits(newState[1], plnDecimals),
        depositPLN: ethers.utils.formatUnits(newState[2], plnDecimals),
        isActive: newState[4]
      });
      
      return {
        success: true,
        transactionHash: tx.hash,
        blockNumber: receipt.blockNumber,
        newState
      };
    } catch (error) {
      let revertReason = 'Unknown error';
      if (error.data) {
        try {
          const decodedError = portfolio.interface.parseError(error.data);
          revertReason = decodedError.signature;
        } catch (e) {
          revertReason = error.reason || error.message;
        }
      } else {
        revertReason = error.reason || error.message;
      }
      
      console.error('❌ Error withdrawing funds:', revertReason);
      throw new Error(`Withdrawal failed: ${revertReason}`);
    }
  };
  
  // Add getDefaultWeights method
  tester.getDefaultWeights = async () => {
    try {
      // Return weights for 7 assets that sum up to 100 (100%)
      const numAssets = 7;
      const weight = Math.floor(100 / numAssets);
      // Distribute the remainder to ensure the total is exactly 100
      const weights = Array(numAssets).fill(weight);
      const remainder = 100 - (weight * numAssets);
      if (remainder > 0) {
        weights[0] += remainder; // Add the remainder to the first weight
      }
      
      console.log('Using portfolio weights (percentages):', weights);
      console.log('Sum of weights:', weights.reduce((a, b) => a + b, 0));
      
      return weights;
    } catch (error) {
      console.error('Error getting default weights:', error);
      throw error;
    }
  };
  
  // Add getDefaultIsShort method
  tester.getDefaultIsShort = (weights) => {
    // For now, all positions are long
    return Array(weights.length).fill(false);
  };
  
  // Add getPortfolioState method
  tester.getPortfolioState = async () => {
    try {
      console.log('🔄 Fetching portfolio data...');
      const portfolioData = await portfolio.getPortfolio(wallet.address, contracts.plnToken);
      
      console.log('📊 Raw portfolio data:', {
        length: portfolioData.length,
        data: portfolioData.map(d => d.toString())
      });
      
      // If the portfolio doesn't exist, return null
      if (!portfolioData || portfolioData.length === 0) {
        console.log('ℹ️ No portfolio data found');
        return null;
      }
      
      // Extract relevant data from the portfolio
      const [weights, totalValue, depositPLN, , isActive] = portfolioData;
      
      // Handle large numbers by keeping them as strings or BigNumber
      const formattedWeights = weights.map(w => w.toString());
      
      const result = {
        totalValue: ethers.utils.formatUnits(totalValue.toString(), plnDecimals),
        totalValueWei: totalValue.toString(),
        depositPLN: ethers.utils.formatUnits(depositPLN.toString(), plnDecimals),
        depositPLNWei: depositPLN.toString(),
        isActive: isActive,
        weights: formattedWeights,
        raw: portfolioData.map(d => d.toString())
      };
      
      console.log('📝 Formatted portfolio state:', JSON.stringify(result, null, 2));
      return result;
    } catch (error) {
      return null;
    }
  };
  
  // Add getBalances method
  tester.getBalances = async () => {
    try {
      // Get ETH balance
      const ethBalance = await wallet.getBalance();
      
      // Get PLN balance
      const plnBalance = await plnToken.balanceOf(wallet.address);
      
      // Get PLN allowance for portfolio contract
      const plnAllowance = await plnToken.allowance(wallet.address, contracts.portfolio);
      
      return {
        ethBalance,
        plnBalance,
        plnAllowance,
        plnDecimals: 18 // Hardcoded for now, could be fetched from token contract
      };
    } catch (error) {
      console.error('Error getting balances:', error);
      throw error;
    }
  };
  
  return tester;
}

/**
 * Tests wallet functionality including portfolio creation, deposits, rebalancing, and withdrawals
 * @param {Object} walletInfo - Wallet information including address and private key
 * @param {Object} [options] - Test options
 * @param {number} [options.depositAmount=1] - Amount in PLN to deposit (default: 1)
 * @param {boolean} [options.autoCreate=true] - Whether to automatically create a portfolio if needed
 * @param {boolean} [options.testWithdraw=true] - Whether to test withdrawal functionality
 * @param {boolean} [options.testRebalance=true] - Whether to test rebalancing functionality
 * @returns {Promise<Object>} Test results
 */
async function testWallet(walletInfo, options = {}) {
  const result = {
    wallet: walletInfo.address,
    success: false,
    steps: {},
    error: null,
    transactions: []
  };

  const {
    depositAmount = 2,   // Default to 2 PLN
    autoCreate = true,   // Auto-create portfolio if needed
    minEthBalance = '0.003', // Minimum ETH balance required (for gas)
    testWithdraw = true, // Test withdrawal functionality
    testRebalance = true, // Test rebalancing functionality
    skipCreate = false   // Skip portfolio creation if it already exists
  } = options;

  console.log(`\n=== Testing Wallet: ${walletInfo.address} ===`);
  console.log(`Using deposit amount: ${depositAmount} PLN`);
  console.log(`Auto-create: ${autoCreate}, Test Withdraw: ${testWithdraw}, Test Rebalance: ${testRebalance}`);

  // Initialize provider and wallet
  const provider = new ethers.providers.JsonRpcProvider(process.env.RPC_URL || 'https://sepolia.base.org');
  
  // Track test steps
  const steps = {};
  let currentStep = 0;
  
  const logStep = (stepName, message) => {
    currentStep++;
    const stepKey = `${currentStep}. ${stepName}`;
    console.log(`\n${stepKey}: ${message}`);
    steps[stepKey] = { status: 'started', message };
    return stepKey;
  };
  
  const completeStep = (stepKey, data = {}) => {
    steps[stepKey] = { ...steps[stepKey], status: 'completed', ...data };
    console.log(`✅ ${stepKey}: Completed`);
  };
  
  const failStep = (stepKey, error) => {
    console.error(`❌ ${stepKey}: Failed - ${error.message}`);
    steps[stepKey] = { ...steps[stepKey], status: 'failed', error: error.message };
    throw error;
  };

  // Create wallet and tester with error handling
  let tester;
  try {
    const wallet = new ethers.Wallet(walletInfo.privateKey, provider);
    const network = await provider.getNetwork();
    console.log(`\n🔗 Connected to network: ${network.name || 'unknown'} (${network.chainId})`);
    
    // Contract addresses from Sepolia Developer Guide
    const contractAddresses = {
      portfolio: '0xEF789258233E6cFBB5E0bb093FC9537E69e81Bb7', // PORTFOLIO_CONTRACT
      plnToken: '0x9E1c51E1fAa1381D8a7Dbdd19402c5fCce9274C6', // PLN_TOKEN
      vepln: '0x3a28AB567b661B3edaF9Ef0bDE9489558EDB3995'   // vePLN
    };

    console.log('Using contract addresses from Sepolia Developer Guide:');
    console.log('Using contract addresses:', JSON.stringify(contractAddresses, null, 2));

    // Create tester instance using factory function
    tester = createPortfolioTester(wallet, provider, contractAddresses);

    // Initialize the tester
    const initSuccess = await tester.initialize();
    if (!initSuccess) {
      throw new Error('Failed to initialize tester');
    }
  } catch (error) {
    console.error('❌ Failed to initialize tester:', error.message);
    return { success: false, error: 'Tester initialization failed' };
  }
  
  try {
    // 1. Check initial balances
    let stepKey = logStep('Check Balances', 'Checking initial balances...');
    try {
      const balances = await tester.getBalances();
      console.log('💰 Balances:', {
        ETH: ethers.utils.formatEther(balances.ethBalance),
        PLN: ethers.utils.formatUnits(balances.plnBalance, balances.plnDecimals),
        'PLN Allowance': ethers.utils.formatUnits(balances.plnAllowance, balances.plnDecimals)
      });
      
      // Check if we have enough ETH for gas
      const minEth = ethers.utils.parseEther(minEthBalance);
      if (balances.ethBalance.lt(minEth)) {
        throw new Error(`Insufficient ETH balance for gas. Need at least ${minEthBalance} ETH, have ${ethers.utils.formatEther(balances.ethBalance)}`);
      }
      
      completeStep(stepKey, { balances });
    } catch (error) {
      failStep(stepKey, error);
    }
    
    // 2. Check portfolio status
    stepKey = logStep('Check Portfolio', 'Checking if portfolio exists...');
    let portfolioExists = false;
    let portfolioState = null;
    
    try {
      portfolioState = await tester.getPortfolioState();
      if (portfolioState) {
        console.log('✅ Portfolio exists:', {
          totalValue: portfolioState.totalValue,
          depositPLN: portfolioState.depositPLN,
          isActive: portfolioState.isActive,
          weights: portfolioState.weights
        });
        portfolioExists = true;
        completeStep(stepKey, { portfolioState });
      } else {
        console.log('ℹ️ No portfolio found');
        completeStep(stepKey, { portfolioState: null });
      }
    } catch (error) {
      console.log('ℹ️ Error checking portfolio state, assuming no portfolio exists:', error.message);
      completeStep(stepKey, { error: error.message, portfolioState: null });
    }
    
    // 3. Create portfolio if needed
    if ((!portfolioState || !portfolioState.isActive) && autoCreate && !skipCreate) {
      stepKey = logStep('Create Portfolio', `Creating new portfolio with ${depositAmount} PLN...`);
      try {
        console.log('🔄 Creating new portfolio...');
        const createResult = await tester.createPortfolio(depositAmount);
        
        if (!createResult.success) {
          throw new Error(`Failed to create portfolio: ${createResult.error}`);
        }
        
        result.transactions.push({
          type: 'create_portfolio',
          hash: createResult.transactionHash,
          blockNumber: createResult.blockNumber,
          amount: depositAmount
        });
        
        console.log(`✅ Portfolio created. Transaction hash: ${createResult.transactionHash}`);
        completeStep(stepKey, { transactionHash: createResult.transactionHash });
      } catch (error) {
        failStep(stepKey, error);
      }
    } else if (!portfolioExists && !autoCreate) {
      console.log('ℹ️ Auto-create is disabled and no portfolio exists. Skipping...');
    }
    
    // 4. Check portfolio state after creation
    stepKey = logStep('Verify Portfolio', 'Verifying portfolio state...');
    try {
      const portfolioState = await tester.getPortfolioState();
      if (!portfolioState || !portfolioState.isActive) {
        throw new Error('Portfolio is not active after creation');
      }
      
      console.log('✅ Portfolio is active:', portfolioState);
      completeStep(stepKey, { portfolioState });
      
      // 5. Deposit funds to portfolio
      stepKey = logStep('Deposit Funds', `Depositing ${depositAmount} PLN to portfolio...`);
      try {
        const depositResult = await tester.depositPLN(depositAmount);
        
        if (!depositResult.success) {
          throw new Error(`Failed to deposit funds: ${depositResult.error}`);
        }
        
        result.transactions.push({
          type: 'deposit',
          hash: depositResult.transactionHash,
          blockNumber: depositResult.blockNumber,
          amount: depositAmount
        });
        
        console.log(`✅ Deposit of ${depositAmount} PLN successful. Transaction hash: ${depositResult.transactionHash}`);
        completeStep(stepKey, { transactionHash: depositResult.transactionHash });
      } catch (error) {
        failStep(stepKey, error);
      }
    } catch (error) {
      failStep(stepKey, error);
    }
    
    // 5. Test rebalancing if enabled
    if (testRebalance) {
      stepKey = logStep('Test Rebalance', 'Testing portfolio rebalancing...');
      try {
        console.log('🔄 Rebalancing portfolio...');
        
        // Get current weights and modify them for testing
        const currentWeights = await tester.getDefaultWeights();
        const newWeights = [...currentWeights];
        
        // Rotate weights for testing
        const firstWeight = newWeights.shift();
        newWeights.push(firstWeight);
        
        console.log('Original weights:', currentWeights);
        console.log('New weights:', newWeights);
        
        const rebalanceResult = await tester.rebalancePortfolio(newWeights);
        
        if (!rebalanceResult.success) {
          throw new Error(`Rebalance failed: ${rebalanceResult.error}`);
        }
        
        result.transactions.push({
          type: 'rebalance',
          hash: rebalanceResult.transactionHash,
          blockNumber: rebalanceResult.blockNumber,
          weights: newWeights
        });
        
        console.log(`✅ Portfolio rebalanced. Transaction hash: ${rebalanceResult.transactionHash}`);
        completeStep(stepKey, { transactionHash: rebalanceResult.transactionHash });
      } catch (error) {
        console.warn('⚠️ Rebalance test failed, but continuing:', error.message);
        steps[stepKey] = { ...steps[stepKey], status: 'skipped', error: error.message };
      }
    }
    
    // 6. Test withdrawal if enabled
    if (testWithdraw) {
      stepKey = logStep('Test Withdrawal', 'Testing withdrawal functionality...');
      try {
        // Withdraw half of the deposited amount
        const withdrawAmount = depositAmount / 2;
        console.log(`💸 Withdrawing ${withdrawAmount} PLN...`);
        
        const withdrawResult = await tester.withdrawFunds(withdrawAmount);
        
        if (!withdrawResult.success) {
          throw new Error(`Withdrawal failed: ${withdrawResult.error}`);
        }
        
        result.transactions.push({
          type: 'withdraw',
          hash: withdrawResult.transactionHash,
          blockNumber: withdrawResult.blockNumber,
          amount: withdrawAmount,
          newState: withdrawResult.newState
        });
        
        console.log(`✅ Withdrawal successful. Transaction hash: ${withdrawResult.transactionHash}`);
        completeStep(stepKey, { 
          transactionHash: withdrawResult.transactionHash,
          amount: withdrawAmount 
        });
      } catch (error) {
        console.warn('⚠️ Withdrawal test failed, but continuing:', error.message);
        steps[stepKey] = { ...steps[stepKey], status: 'skipped', error: error.message };
      }
    }
    
    // 7. Final check
    stepKey = logStep('Final Check', 'Verifying final state...');
    try {
      const finalBalances = await tester.getBalances();
      const finalPortfolio = await tester.getPortfolioState();
      
      console.log('💰 Final Balances:', {
        ETH: ethers.utils.formatEther(finalBalances.ethBalance),
        PLN: ethers.utils.formatUnits(finalBalances.plnBalance, finalBalances.plnDecimals),
        'PLN Allowance': ethers.utils.formatUnits(finalBalances.plnAllowance, finalBalances.plnDecimals)
      });
      
      if (finalPortfolio) {
        console.log('🏦 Final Portfolio State:', finalPortfolio);
      }
      
      completeStep(stepKey, { 
        balances: finalBalances,
        portfolio: finalPortfolio 
      });
    } catch (error) {
      console.warn('⚠️ Final check had issues:', error.message);
      steps[stepKey] = { ...steps[stepKey], status: 'warning', error: error.message };
    }
    
    // Mark test as successful if we got this far
    result.success = true;
    result.steps = steps;
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    result.error = error.message;
    result.success = false;
    result.steps = steps;
  } finally {
    console.log('\n🏁 Test completed');
    
    // Log final result
    if (result.success) {
      console.log('✅ All tests passed successfully!');
    } else if (result.error) {
      console.error('❌ Test failed:', result.error);
    }
    
    // Log transaction hashes
    if (result.transactions && result.transactions.length > 0) {
      console.log('\n📝 Transaction Summary:');
      result.transactions.forEach((tx, index) => {
        console.log(`${index + 1}. ${tx.type}: ${tx.hash}`);
        console.log(`   Block: ${tx.blockNumber}, Amount: ${tx.amount || 'N/A'}`);
      });
    }
    
    return result;
  }
}

async function main() {
  console.log('=== Testing Funded Wallets ===');
  
  // Test each wallet sequentially with 2 PLN deposit
  for (const wallet of FUNDED_WALLETS) {
    await testWallet(wallet, {
      depositAmount: 2, // Using 2 PLN as requested
      autoCreate: true
    });
    
    // Add a small delay between wallets
    if (wallet !== FUNDED_WALLETS[FUNDED_WALLETS.length - 1]) {
      console.log('\n⏳ Waiting before testing next wallet...');
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
  
  console.log('\n=== All tests completed ===');
}

// Run the tests
main()
  .then(() => process.exit(0))
  .catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
  });
