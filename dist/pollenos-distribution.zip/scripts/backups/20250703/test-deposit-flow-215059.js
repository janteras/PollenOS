// test-deposit-flow.js
require('dotenv').config({ path: require('path').resolve(__dirname, '.wallets') });
const { ethers } = require('ethers');
const fs = require('fs');

// Load private keys from .wallets file
const WALLETS = [
  process.env.PRIVATE_KEY_1,
  process.env.PRIVATE_KEY_2,
  process.env.PRIVATE_KEY_3,
  process.env.PRIVATE_KEY_4,
  process.env.PRIVATE_KEY_5
].filter(Boolean);

if (WALLETS.length === 0) {
  console.error('❌ No private keys found in .wallets file');
  process.exit(1);
}

// Configuration
const CONFIG = {
  RPC_URL: 'https://sepolia.base.org',
  CHAIN_ID: 84532,
  CONTRACTS: {
    PLN: '0x9E1c51E1fAa1381D8a7Dbdd19402c5fCce9274C6',
    PORTFOLIO: '0xEF789258233E6cFBB5E0bb093FC9537E69e81Bb7',
  },
  WALLETS: WALLETS
};

// Test configuration
const TEST_CONFIG = {
  depositAmount: '0.5', // PLN amount to deposit
  testWallets: [
    { 
      privateKey: process.env.PRIVATE_KEY_1,
      description: 'Test Wallet 1'
    }
  ],
  // Test different position types
  testPositions: [
    {
      name: 'Long Position',
      weights: [20, 20, 20, 20, 10, 5, 5], // Must sum to 100
      isShort: [false, false, false, false, false, false, false],
      tokenType: false // PLN
    },
    {
      name: 'Short Position',
      weights: [30, 25, 20, 15, 5, 3, 2], // Must sum to 100
      isShort: [true, true, true, true, true, true, true],
      tokenType: true // vePLN
    }
  ]
};

// Contract ABIs
const PORTFOLIO_ABI = [
  'function depositPLN(uint256 amount, address recipient)',
  'function createPortfolio(uint256 amount, uint256[] calldata weights, bool[] calldata isShort, bool tokenType)',
  'function getPortfolio(address user, address token) view returns (uint256[], uint256, uint256, uint256, bool, uint256, uint256, bool[])',
  'function rebalancePortfolio(uint256[] calldata newWeights, bool[] calldata newIsShort)',
  'event PortfolioCreated(address indexed user, address indexed token, uint256 amount, uint256[] weights, bool[] isShort, bool tokenType)'
];

const ERC20_ABI = [
  'function balanceOf(address) view returns (uint256)',
  'function allowance(address, address) view returns (uint256)',
  'function approve(address, uint256) returns (bool)',
  'function symbol() view returns (string)',
  'function decimals() view returns (uint8)',
  'function transfer(address, uint256) returns (bool)'
];

// Test logger
const logger = {
  info: (message, data = '') => console.log(`[INFO] ${message}`, data),
  success: (message) => console.log(`✅ ${message}`),
  error: (message, error = '') => console.error(`❌ ${message}`, error),
  section: (title) => console.log(`\n=== ${title} ===\n`)
};

class PortfolioTester {
  constructor(privateKey, provider) {
    this.wallet = new ethers.Wallet(privateKey, provider);
    this.plnToken = new ethers.Contract(CONFIG.CONTRACTS.PLN, ERC20_ABI, this.wallet);
    this.portfolio = new ethers.Contract(CONFIG.CONTRACTS.PORTFOLIO, PORTFOLIO_ABI, this.wallet);
    this.plnDecimals = null;
  }

  async initialize() {
    this.plnDecimals = await this.plnToken.decimals();
    logger.info(`Initialized tester for wallet: ${this.wallet.address}`);
    return this;
  }

  async checkBalances() {
    const ethBalance = await this.wallet.getBalance();
    const plnBalance = await this.plnToken.balanceOf(this.wallet.address);
    
    logger.info('Balances:', {
      ETH: ethers.utils.formatEther(ethBalance),
      PLN: ethers.utils.formatUnits(plnBalance, this.plnDecimals)
    });

    return { ethBalance, plnBalance };
  }

  async checkPortfolio() {
    try {
      const portfolioData = await this.portfolio.getPortfolio(
        this.wallet.address,
        ethers.constants.AddressZero
      );
      
      const portfolioInfo = {
        exists: true,
        isActive: portfolioData[4],
        totalValue: ethers.utils.formatUnits(portfolioData[1], this.plnDecimals),
        weights: portfolioData[0].map(w => w.toString()),
        isShort: portfolioData[7] || []
      };
      
      logger.info('Portfolio exists:', portfolioInfo);
      return portfolioInfo;
    } catch (error) {
      if (error.reason === 'Portfolio does not exist') {
        logger.info('No portfolio exists for this wallet');
        return { exists: false };
      }
      throw error;
    }
  }

  async ensureApproval(amountWei) {
    const allowance = await this.plnToken.allowance(
      this.wallet.address,
      CONFIG.CONTRACTS.PORTFOLIO
    );

    if (allowance.lt(amountWei)) {
      logger.info(`Approving ${ethers.utils.formatUnits(amountWei, this.plnDecimals)} PLN...`);
      const approveTx = await this.plnToken.approve(
        CONFIG.CONTRACTS.PORTFOLIO,
        amountWei,
        { gasLimit: 200000 }
      );
      await approveTx.wait();
      logger.success('Approval confirmed');
    } else {
      logger.info('Sufficient allowance already set');
    }
  }

  async createPortfolio(amountWei, position) {
    logger.info(`Creating portfolio with position: ${position.name}`);
    
    await this.ensureApproval(amountWei);
    
    logger.info('Creating portfolio with:', {
      amount: ethers.utils.formatUnits(amountWei, this.plnDecimals),
      weights: position.weights,
      isShort: position.isShort,
      tokenType: position.tokenType ? 'vePLN' : 'PLN'
    });

    const tx = await this.portfolio.createPortfolio(
      amountWei,
      position.weights,
      position.isShort,
      position.tokenType,
      { gasLimit: 1500000 }
    );

    logger.info(`Portfolio creation tx: ${tx.hash}`);
    const receipt = await tx.wait();
    logger.success(`Portfolio created in block ${receipt.blockNumber}`);
  }

  async depositPLN(amount, recipient = null) {
    try {
      if (!recipient) recipient = this.wallet.address;
      
      logger.section(`Initiating Deposit of ${amount} PLN`);
      
      // Convert amount to wei and validate
      const amountWei = ethers.utils.parseUnits(amount, this.plnDecimals);
      if (amountWei.lte(0)) {
        throw new Error('Deposit amount must be greater than 0');
      }
      
      logger.info(`Recipient: ${recipient}`);
      logger.info(`Amount: ${amount} PLN (${amountWei.toString()} wei)`);
      
      // Check wallet balance
      const walletBalance = await this.plnToken.balanceOf(this.wallet.address);
      logger.info(`Wallet balance: ${ethers.utils.formatUnits(walletBalance, this.plnDecimals)} PLN`);
      
      if (walletBalance.lt(amountWei)) {
        throw new Error(`Insufficient balance. Required: ${amount} PLN, Available: ${ethers.utils.formatUnits(walletBalance, this.plnDecimals)} PLN`);
      }
      
      // Check allowance and approve if needed
      const allowance = await this.plnToken.allowance(this.wallet.address, this.portfolio.address);
      logger.info(`Current allowance: ${ethers.utils.formatUnits(allowance, this.plnDecimals)} PLN`);
      
      if (allowance.lt(amountWei)) {
        logger.info('Approving PLN token spend...');
        const approveTx = await this.plnToken.approve(this.portfolio.address, amountWei);
        logger.info(`Approval tx hash: ${approveTx.hash}`);
        const approveReceipt = await approveTx.wait();
        logger.info(`Approval confirmed in block ${approveReceipt.blockNumber}`);
        
        // Verify new allowance
        const newAllowance = await this.plnToken.allowance(this.wallet.address, this.portfolio.address);
        logger.info(`New allowance: ${ethers.utils.formatUnits(newAllowance, this.plnDecimals)} PLN`);
        
        if (newAllowance.lt(amountWei)) {
          throw new Error('Failed to set sufficient allowance');
        }
      }
      
      // Get current portfolio state with detailed logging
      logger.info('\n📊 Current portfolio state before deposit:');
      const portfolioState = await this.portfolio.getPortfolio(this.wallet.address, this.plnToken.address);
      logger.info(JSON.stringify({
        totalValue: portfolioState[1].toString(),
        depositPLN: portfolioState[2].toString(),
        isActive: portfolioState[4],
        rawState: portfolioState.map((val, idx) => ({
          index: idx,
          value: val.toString(),
          type: typeof val
        }))
      }, null, 2));
      
      // Get gas price
      const gasPrice = await this.wallet.provider.getGasPrice();
      
      logger.info('\n🚀 Sending deposit transaction...');
      logger.info(`From: ${this.wallet.address}`);
      logger.info(`To: ${this.portfolio.address}`);
      logger.info(`Value: ${amountWei.toString()} wei`);
      logger.info(`Gas Price: ${ethers.utils.formatUnits(gasPrice, 'gwei')} gwei`);
      
      // Execute deposit with error handling for revert reasons
      let tx, receipt;
      try {
        tx = await this.portfolio.depositPLN(
          amountWei,
          recipient,
          { 
            gasLimit: 1000000,
            gasPrice: gasPrice
          }
        );
        
        logger.info(`✅ Deposit transaction sent. Hash: ${tx.hash}`);
        receipt = await tx.wait();
        logger.info(`✅ Deposit confirmed in block ${receipt.blockNumber}`);
        
        // Log all events from the receipt
        if (receipt.events && receipt.events.length > 0) {
          logger.info('\n📝 Transaction events:');
          receipt.events.forEach((event, i) => {
            logger.info(`  ${i + 1}. ${event.event || 'UnknownEvent'} (${event.eventSignature || 'no signature'})`);
            logger.info(`     Args: ${JSON.stringify(event.args || {}, (_, v) => 
              typeof v === 'bigint' ? v.toString() : v, 2)}`);
          });
        } else {
          logger.info('ℹ️  No events emitted in transaction');
        }
      } catch (error) {
        logger.error('❌ Transaction failed:', error);
        if (error.transactionHash) {
          logger.info(`Transaction hash: ${error.transactionHash}`);
          // Try to get the revert reason
          try {
            const tx = await this.wallet.provider.getTransaction(error.transactionHash);
            const code = await this.wallet.provider.call(tx, tx.blockNumber);
            const reason = ethers.utils.toUtf8String('0x' + code.substr(138));
            logger.info(`Revert reason: ${reason}`);
          } catch (e) {
            logger.info('Could not decode revert reason:', e.message);
          }
        }
        throw error;
      }
      
      // Get updated portfolio state with delay to ensure state is updated
      logger.info('\n⏳ Waiting for state updates...');
      await new Promise(resolve => setTimeout(resolve, 5000)); // 5 second delay
      
      logger.info('\n📊 Updated portfolio state after deposit:');
      const newState = await this.portfolio.getPortfolio(this.wallet.address, this.plnToken.address);
      logger.info(JSON.stringify({
        totalValue: newState[1].toString(),
        depositPLN: newState[2].toString(),
        isActive: newState[4],
        rawState: newState.map((val, idx) => ({
          index: idx,
          value: val.toString(),
          type: typeof val
        }))
      }, null, 2));
      
      // Verify the deposit was successful
      const depositIncreased = newState[2].gt(portfolioState[2]);
      logger.info(`\n🔍 Deposit verification: ${depositIncreased ? '✅ Success' : '❌ Failed'}`);
      if (!depositIncreased) {
        logger.info('Warning: Deposit amount did not increase after transaction');
        logger.info('Possible issues:');
        logger.info('1. The transaction may have reverted without throwing an error');
        logger.info('2. The depositPLN function may not be updating the state correctly');
        logger.info('3. There might be an issue with the contract state management');
      }
      
      return receipt;
    } catch (error) {
      logger.error('Deposit failed:', error);
      throw error;
    }
  }

  async testPosition(position) {
    try {
      logger.section(`Testing ${position.name}`);
      
      // Create portfolio with the position
      await this.createPortfolio(
        ethers.utils.parseUnits(TEST_CONFIG.depositAmount, this.plnDecimals),
        position
      );
      
      // Test deposit with detailed logging
      logger.info(`\n=== Testing Deposit ===`);
      await this.depositPLN(TEST_CONFIG.depositAmount, this.wallet.address);
      
      // Test rebalance
      logger.info(`\n=== Testing Rebalance ===`);
      const newWeights = [...position.weights].reverse(); // Reverse weights for testing
      await this.rebalancePortfolio(newWeights, position.isShort);
      
      // Get current portfolio state before withdrawal
      logger.info('\n📊 Portfolio state before withdrawal:');
      const portfolioState = await this.portfolio.getPortfolio(this.wallet.address, this.plnToken.address);
      logger.info(JSON.stringify({
        totalValue: portfolioState[1].toString(),
        depositPLN: portfolioState[2].toString(),
        isActive: portfolioState[4]
      }, null, 2));
      
      // Test withdrawal
      logger.info(`\n=== Testing Withdrawal ===`);
      const withdrawAmount = (parseFloat(TEST_CONFIG.depositAmount) / 2).toString(); // Withdraw half
      await this.withdraw(withdrawAmount);
      
      // Verify final state
      logger.info('\n📊 Final portfolio state:');
      const finalState = await this.portfolio.getPortfolio(this.wallet.address, this.plnToken.address);
      logger.info(JSON.stringify({
        totalValue: finalState[1].toString(),
        depositPLN: finalState[2].toString(),
        isActive: finalState[4]
      }, null, 2));
      
      logger.success(`✅ ${position.name} tests passed!\n`);
      return true;
    } catch (error) {
      logger.error(`❌ ${position.name} tests failed:`, error);
      if (error.transactionHash) {
        logger.error('Transaction hash:', error.transactionHash);
      }
      return false;
    }
  }
}

async function runTests() {
  if (CONFIG.WALLETS.length === 0) {
    logger.error('No valid private keys found in .wallets file');
    process.exit(1);
  }

  const provider = new ethers.providers.JsonRpcProvider(CONFIG.RPC_URL, {
    name: 'base-sepolia',
    chainId: CONFIG.CHAIN_ID,
  });

  logger.section('Starting Portfolio Deposit Tests');
  
  try {
    // Test with the first wallet
    const tester = await new PortfolioTester(CONFIG.WALLETS[0], provider).initialize();
    
    // Run tests for each position type
    for (const position of TEST_CONFIG.testPositions) {
      await tester.testPosition(position);
      // Add delay between tests
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
    
    logger.section('All Tests Completed');
  } catch (error) {
    logger.error('Fatal error in test:', error);
    process.exit(1);
  }
}

// Run tests
runTests().catch(console.error);
