require('dotenv').config({ path: require('path').resolve(__dirname, '../base-sepolia.env') });
const { ethers } = require('ethers');

// Base Sepolia Contract Addresses
const CONFIG = {
  RPC_URL: 'https://sepolia.base.org',
  CHAIN_ID: 84532,
  CONTRACTS: {
    PLN: '0x9E1c51E1fAa1381D8a7Dbdd19402c5fCce9274C6', // PLN Token
    VEPLN: '0x3a28AB567b661B3edaF9Ef0bDE9489558EDB3995', // vePLN Contract
    POLLEN_DAO: '0xEF789258233E6cFBB5E0bb093FC9537E69e81Bb7',
    LEAGUES: '0x55F04Ee2775925b80125F412C05cF5214Fd1317a'
  }
};

// Contract ABIs
const ERC20_ABI = [
  'function balanceOf(address) view returns (uint256)',
  'function allowance(address, address) view returns (uint256)',
  'function approve(address spender, uint256 amount) returns (bool)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)'
];

const VEPLN_ABI = [
  'function create_lock(uint256 _value, uint256 _unlock_time) external',
  'function locked(address) view returns (int128 amount, uint256 end)',
  'function token() external view returns (address)',
  'function version() external view returns (string)'
];

async function getContractInfo(contract, name) {
  try {
    const info = {};
    
    // Try to get basic info
    if (contract.name) {
      info.name = await contract.name();
    }
    
    if (contract.symbol) {
      info.symbol = await contract.symbol();
    }
    
    if (contract.decimals) {
      info.decimals = await contract.decimals();
    }
    
    if (contract.version) {
      info.version = await contract.version().catch(() => 'unknown');
    }
    
    if (contract.token) {
      info.token = await contract.token().catch(() => 'unknown');
    }
    
    console.log(`\n=== ${name} Contract Info ===`);
    console.log(`Address: ${contract.address}`);
    Object.entries(info).forEach(([key, value]) => {
      console.log(`${key.charAt(0).toUpperCase() + key.slice(1)}: ${value}`);
    });
    
    return info;
  } catch (error) {
    console.error(`Error getting ${name} info:`, error.message);
    return {};
  }
}

async function main() {
  console.log('🚀 Starting portfolio creation process...');
  
  // Initialize provider and wallet
  const provider = new ethers.providers.JsonRpcProvider(CONFIG.RPC_URL);
  const wallet = new ethers.Wallet(process.env.WALLET_PRIVATE_KEY, provider);
  
  console.log(`🌐 Network: Base Sepolia (Chain ID: ${(await provider.getNetwork()).chainId})`);
  console.log(`🔗 RPC URL: ${CONFIG.RPC_URL}`);
  console.log(`🔑 Wallet: ${wallet.address}`);
  
  // Check ETH balance for gas
  const ethBalance = await provider.getBalance(wallet.address);
  console.log(`💰 ETH Balance: ${ethers.utils.formatEther(ethBalance)} ETH`);
  
  if (ethBalance.lt(ethers.utils.parseEther('0.01'))) {
    throw new Error('Insufficient ETH for gas. Please fund your wallet.');
  }
  
  // Initialize contracts
  const plnToken = new ethers.Contract(CONFIG.CONTRACTS.PLN, ERC20_ABI, wallet);
  const vePln = new ethers.Contract(CONFIG.CONTRACTS.VEPLN, VEPLN_ABI, wallet);
  
  // Get contract info
  await getContractInfo(plnToken, 'PLN Token');
  await getContractInfo(vePln, 'vePLN');
  
  // Check PLN balance
  const plnBalance = await plnToken.balanceOf(wallet.address);
  console.log(`\n💰 Your PLN Balance: ${ethers.utils.formatEther(plnBalance)} PLN`);
  
  if (plnBalance.isZero()) {
    throw new Error('Insufficient PLN balance. Please acquire some PLN tokens.');
  }
  
  // Check allowance
  const allowance = await plnToken.allowance(wallet.address, CONFIG.CONTRACTS.VEPLN);
  console.log(`\n🔒 Current allowance for vePLN: ${ethers.utils.formatEther(allowance)} PLN`);
  
  // Approve vePLN to spend PLN if needed
  if (allowance.lt(plnBalance)) {
    console.log('\n🔓 Approving vePLN to spend PLN...');
    try {
      const gasPrice = (await provider.getGasPrice()).mul(2); // Add buffer
      const approveTx = await plnToken.approve(
        CONFIG.CONTRACTS.VEPLN,
        ethers.constants.MaxUint256,
        {
          gasLimit: 200000, // Higher gas limit for token approvals
          gasPrice: gasPrice
        }
      );
      
      console.log(`⏳ Waiting for approval confirmation...`);
      const receipt = await approveTx.wait();
      console.log(`✅ Approval confirmed in tx: ${receipt.transactionHash}`);
      console.log(`   Gas used: ${receipt.gasUsed.toString()}`);
      
      // Verify the new allowance
      const newAllowance = await plnToken.allowance(wallet.address, CONFIG.CONTRACTS.VEPLN);
      console.log(`   New allowance: ${ethers.utils.formatEther(newAllowance)} PLN`);
      
    } catch (error) {
      console.error('❌ Approval failed:', error.message);
      if (error.transactionHash) {
        console.log(`   Transaction hash: ${error.transactionHash}`);
      }
      throw error;
    }
  }
  
  // Check if already locked
  try {
    const locked = await vePln.locked(wallet.address);
    if (locked.amount.gt(0)) {
      console.log('\n🔍 Found existing locked position:');
      console.log(`   Amount: ${ethers.utils.formatEther(locked.amount)} PLN`);
      console.log(`   Unlocks at: ${new Date(locked.end * 1000).toISOString()}`);
      
      const now = Math.floor(Date.now() / 1000);
      if (locked.end > now) {
        console.log('\n⚠️  You already have a locked position. Creating a new one will replace the existing lock.');
      }
    }
  } catch (error) {
    console.log('\nℹ️  No existing locked position found or error checking lock status:', error.message);
  }
  
  // Calculate unlock time (1 year from now)
  const oneYearInSeconds = 365 * 24 * 60 * 60;
  const unlockTime = Math.floor(Date.now() / 1000) + oneYearInSeconds;
  
  // Amount to lock (all available PLN)
  const amountToLock = plnBalance;
  
  console.log(`\n🔐 Attempting to lock ${ethers.utils.formatEther(amountToLock)} PLN for 1 year...`);
  console.log(`   Unlock time: ${new Date(unlockTime * 1000).toISOString()}`);
  
  // Create lock
  try {
    console.log('\n📡 Sending create_lock transaction...');
    
    // Get gas price with buffer
    const gasPrice = (await provider.getGasPrice()).mul(2);
    
    // Send transaction with manual gas settings
    const tx = await vePln.create_lock(
      amountToLock,
      unlockTime,
      {
        gasLimit: 500000, // Higher gas limit
        gasPrice: gasPrice,
        nonce: await provider.getTransactionCount(wallet.address, 'latest')
      }
    );
    
    console.log(`\n⏳ Transaction sent: ${tx.hash}`);
    console.log(`   Waiting for confirmation...`);
    
    const receipt = await tx.wait();
    
    console.log(`\n✅ Transaction confirmed in block ${receipt.blockNumber}`);
    console.log(`   Gas used: ${receipt.gasUsed.toString()}`);
    console.log(`   Status: ${receipt.status === 1 ? 'Success' : 'Failed'}`);
    
    if (receipt.status === 1) {
      console.log('\n🎉 Portfolio created successfully!');
      
      // Check the locked amount
      try {
        const locked = await vePln.locked(wallet.address);
        console.log(`\n🔒 Locked details:`);
        console.log(`   Amount: ${ethers.utils.formatEther(locked.amount)} PLN`);
        console.log(`   Unlock time: ${new Date(locked.end * 1000).toISOString()}`);
      } catch (error) {
        console.log('\n⚠️  Could not verify locked amount:', error.message);
      }
    } else {
      console.log('\n❌ Transaction reverted!');
    }
    
  } catch (error) {
    console.error('\n❌ Error creating portfolio:', error.message);
    
    if (error.transactionHash) {
      console.log(`\n📄 Transaction hash: ${error.transactionHash}`);
      console.log(`   Check the transaction on: https://sepolia.basescan.org/tx/${error.transactionHash}`);
    }
    
    if (error.reason) {
      console.log(`\n🔍 Reason: ${error.reason}`);
    }
    
    if (error.code === 'INSUFFICIENT_FUNDS') {
      console.log('💡 Tip: You might need more ETH for gas.');
    } else if (error.code === 'UNPREDICTABLE_GAS_LIMIT') {
      console.log('💡 Tip: The transaction might fail due to contract logic or parameters.');
    } else if (error.code === 'NETWORK_ERROR') {
      console.log('💡 Tip: There might be an issue with the RPC endpoint. Try again later.');
    }
    
    process.exit(1);
  }
}

main().catch((error) => {
  console.error('\n❌ Script failed:', error.message);
  console.log('\n💡 Tips for troubleshooting:');
  console.log('1. Check that you have enough ETH for gas');
  console.log('2. Verify the contract addresses are correct');
  console.log('3. Check if the contract is paused or has any restrictions');
  console.log('4. Try increasing the gas price if the transaction is stuck');
  console.log('5. Check the contract on a block explorer for any recent activity or issues');
  
  process.exit(1);
});
