#!/usr/bin/env node

/**
 * Mainnet Testing Script for Pollen Trading Bot
 * 
 * This script validates:
 * 1. PLN Token Staking functionality
 * 2. Portfolio Rebalancing operations
 * 3. Risk management systems
 * 4. Performance benchmarks
 * 
 * Usage:
 * npm run test:mainnet
 * OR
 * node scripts/mainnet-test.js --network=avalanche --test-mode=validation
 */

const { ethers } = require('ethers');
const chalk = require('chalk');
const readline = require('readline');

// Import modules
const PollenAPI = require('../src/modules/pollen-api');
const TradingViewModule = require('../src/modules/tradingview');
const Logger = require('../src/modules/logger');

class MainnetValidator {
  constructor(options = {}) {
    this.network = options.network || 'avalanche';
    this.testMode = options.testMode || 'validation';
    this.logger = new Logger('MainnetValidator');
    this.pollenAPI = null;
    this.tradingView = null;
    this.results = {
      plnStaking: {},
      portfolioRebalancing: {},
      riskManagement: {},
      performance: {},
      overall: { passed: 0, failed: 0, total: 0 }
    };
  }

  async initialize() {
    try {
      console.log(chalk.blue('🚀 Initializing Mainnet Validation...'));
      
      // Set environment for mainnet testing
      process.env.NETWORK = this.network;
      process.env.NODE_ENV = 'production';
      
      // Initialize APIs
      this.pollenAPI = new PollenAPI();
      this.tradingView = new TradingViewModule();
      
      // Verify connections
      const walletConnected = await this.pollenAPI.verifyWalletConnection();
      const contractsConnected = await this.pollenAPI.verifyContractConnection();
      
      if (!walletConnected || !contractsConnected) {
        throw new Error('Failed to connect to blockchain or contracts');
      }
      
      console.log(chalk.green('✅ Mainnet connections established'));
      
      // Display initial balances
      const balances = await this.pollenAPI.getTokenBalances();
      console.log(chalk.cyan('💰 Initial Balances:'));
      for (const [token, balance] of Object.entries(balances)) {
        console.log(`   ${token}: ${balance}`);
      }
      
      return true;
    } catch (error) {
      console.error(chalk.red('❌ Initialization failed:'), error.message);
      return false;
    }
  }

  async testPLNStaking() {
    console.log(chalk.blue('\n📈 Testing PLN Token Staking...'));
    
    try {
      // Test 1: Verify PLN balance and contract connection
      await this.runTest('PLN Balance Check', async () => {
        const plnBalance = await this.pollenAPI.getPLNBalance();
        if (plnBalance <= 0) {
          throw new Error(`Insufficient PLN balance: ${plnBalance}`);
        }
        console.log(`   PLN Balance: ${plnBalance}`);
        return { plnBalance };
      });

      // Test 2: Check current staking status
      await this.runTest('Staking Status Check', async () => {
        const stakingStatus = await this.pollenAPI.getStakingStatus();
        console.log(`   Current Staked: ${stakingStatus.totalStaked} PLN`);
        console.log(`   Staking Power: ${stakingStatus.stakingPower}`);
        return stakingStatus;
      });

      // Test 3: Small staking test (10 PLN)
      await this.runTest('Small Staking Test', async () => {
        const stakeAmount = ethers.utils.parseEther('10');
        
        // Get user confirmation for actual staking
        const confirmed = await this.confirmAction(
          `Stake 10 PLN tokens? This will execute a real transaction.`
        );
        
        if (!confirmed) {
          console.log(chalk.yellow('   Skipped - User declined'));
          return { skipped: true };
        }
        
        const initialStake = await this.pollenAPI.getStakingStatus();
        const stakingTx = await this.pollenAPI.stakePLNTokens(stakeAmount);
        
        console.log(`   Transaction Hash: ${stakingTx.hash}`);
        
        // Wait for confirmation
        const receipt = await stakingTx.wait();
        if (receipt.status !== 1) {
          throw new Error('Staking transaction failed');
        }
        
        const newStake = await this.pollenAPI.getStakingStatus();
        const stakedIncrease = parseFloat(newStake.totalStaked) - parseFloat(initialStake.totalStaked);
        
        console.log(`   Staked Amount Increased: ${stakedIncrease} PLN`);
        
        return {
          txHash: stakingTx.hash,
          stakedIncrease,
          newTotalStaked: newStake.totalStaked
        };
      });

      // Test 4: Staking rewards calculation
      await this.runTest('Staking Rewards Calculation', async () => {
        const rewardsInfo = await this.pollenAPI.getStakingRewards();
        console.log(`   Current Rewards: ${rewardsInfo.currentRewards}`);
        console.log(`   Reward Rate: ${rewardsInfo.rewardRate}%`);
        console.log(`   Next Reward Date: ${rewardsInfo.nextRewardDate}`);
        return rewardsInfo;
      });

    } catch (error) {
      console.error(chalk.red('❌ PLN Staking tests failed:'), error.message);
    }
  }

  async testPortfolioRebalancing() {
    console.log(chalk.blue('\n⚖️  Testing Portfolio Rebalancing...'));
    
    try {
      // Test 1: Current portfolio analysis
      await this.runTest('Portfolio Analysis', async () => {
        const portfolio = await this.pollenAPI.getCurrentPortfolio();
        console.log(`   Total Value: $${portfolio.totalValue}`);
        console.log(`   Asset Count: ${Object.keys(portfolio.allocations).length}`);
        
        for (const [asset, allocation] of Object.entries(portfolio.allocations)) {
          console.log(`   ${asset}: ${allocation}%`);
        }
        
        return portfolio;
      });

      // Test 2: Rebalancing threshold check
      await this.runTest('Rebalancing Threshold Check', async () => {
        const currentPortfolio = await this.pollenAPI.getCurrentPortfolio();
        const thresholdCheck = await this.pollenAPI.checkRebalanceThreshold(currentPortfolio);
        
        console.log(`   Rebalance Required: ${thresholdCheck.required}`);
        console.log(`   Current Deviation: ${thresholdCheck.deviation}%`);
        console.log(`   Threshold: ${thresholdCheck.threshold}%`);
        
        return thresholdCheck;
      });

    } catch (error) {
      console.error(chalk.red('❌ Portfolio Rebalancing tests failed:'), error.message);
    }
  }

  async testRiskManagement() {
    console.log(chalk.blue('\n🛡️  Testing Risk Management...'));
    
    try {
      // Test 1: Position limits validation
      await this.runTest('Position Limits Check', async () => {
        const limits = await this.pollenAPI.getPositionLimits();
        const portfolio = await this.pollenAPI.getCurrentPortfolio();
        
        console.log(`   Max Per Asset: ${limits.maxPerAsset}%`);
        console.log(`   Max Total: ${limits.maxTotal}%`);
        
        // Check current positions against limits
        let violationsFound = false;
        for (const [asset, allocation] of Object.entries(portfolio.allocations)) {
          if (allocation > limits.maxPerAsset) {
            console.log(chalk.red(`   ⚠️  ${asset} exceeds limit: ${allocation}% > ${limits.maxPerAsset}%`));
            violationsFound = true;
          }
        }
        
        if (!violationsFound) {
          console.log(chalk.green('   ✅ All positions within limits'));
        }
        
        return { limits, portfolio, violationsFound };
      });

      // Test 2: Stop-loss mechanism
      await this.runTest('Stop-Loss Mechanism', async () => {
        const portfolio = await this.pollenAPI.getCurrentPortfolio();
        const stopLossConfig = await this.pollenAPI.getStopLossConfig();
        
        console.log(`   Stop-Loss Threshold: ${stopLossConfig.threshold}%`);
        console.log(`   Current Value: $${portfolio.totalValue}`);
        
        // Simulate a loss scenario
        const simulatedValue = portfolio.totalValue * 0.85; // 15% loss
        const stopLossTriggered = await this.pollenAPI.checkStopLoss(simulatedValue, portfolio.totalValue);
        
        console.log(`   15% Loss Scenario: ${stopLossTriggered.activated ? 'TRIGGERED' : 'Not triggered'}`);
        
        return { stopLossConfig, stopLossTriggered };
      });

      // Test 3: Circuit breakers
      await this.runTest('Circuit Breakers', async () => {
        const circuitBreakers = await this.pollenAPI.getCircuitBreakers();
        
        console.log(`   Rapid Decline: ${circuitBreakers.rapidDecline.threshold}%`);
        console.log(`   High Volatility: ${circuitBreakers.highVolatility.threshold}%`);
        console.log(`   Low Liquidity: $${circuitBreakers.lowLiquidity.threshold}`);
        
        // Test each circuit breaker
        const results = {};
        for (const [type, config] of Object.entries(circuitBreakers)) {
          const status = await this.pollenAPI.checkCircuitBreaker(type);
          results[type] = status;
          console.log(`   ${type}: ${status.activated ? 'ACTIVE' : 'Inactive'}`);
        }
        
        return results;
      });

    } catch (error) {
      console.error(chalk.red('❌ Risk Management tests failed:'), error.message);
    }
  }

  async testPerformance() {
    console.log(chalk.blue('\n⚡ Testing Performance Benchmarks...'));
    
    try {
      // Test 1: Market data fetch speed
      await this.runTest('Market Data Speed', async () => {
        const startTime = Date.now();
        const marketData = await this.tradingView.getMarketData(['WBTC', 'WETH', 'USDC']);
        const executionTime = Date.now() - startTime;
        
        console.log(`   Execution Time: ${executionTime}ms`);
        console.log(`   Target: <3000ms`);
        console.log(`   Status: ${executionTime < 3000 ? '✅ PASS' : '❌ FAIL'}`);
        
        return { executionTime, target: 3000, passed: executionTime < 3000 };
      });

      // Test 2: Portfolio analysis speed
      await this.runTest('Portfolio Analysis Speed', async () => {
        const startTime = Date.now();
        const portfolio = await this.pollenAPI.performPortfolioAnalysis();
        const executionTime = Date.now() - startTime;
        
        console.log(`   Execution Time: ${executionTime}ms`);
        console.log(`   Target: <2000ms`);
        console.log(`   Status: ${executionTime < 2000 ? '✅ PASS' : '❌ FAIL'}`);
        
        return { executionTime, target: 2000, passed: executionTime < 2000 };
      });

      // Test 3: Rebalancing calculation speed
      await this.runTest('Rebalancing Calculation Speed', async () => {
        const startTime = Date.now();
        const rebalanceTargets = await this.pollenAPI.calculateRebalanceTargets();
        const executionTime = Date.now() - startTime;
        
        console.log(`   Execution Time: ${executionTime}ms`);
        console.log(`   Target: <5000ms`);
        console.log(`   Status: ${executionTime < 5000 ? '✅ PASS' : '❌ FAIL'}`);
        
        return { executionTime, target: 5000, passed: executionTime < 5000 };
      });

      // Test 4: Cost efficiency
      await this.runTest('Cost Efficiency', async () => {
        const costMetrics = await this.pollenAPI.getCostEfficiencyMetrics();
        
        console.log(`   Average Gas Cost: $${costMetrics.averageGasCost}`);
        console.log(`   Average Slippage: ${costMetrics.averageSlippage}%`);
        console.log(`   Rebalance Cost: $${costMetrics.rebalancingCosts}`);
        
        const gasTarget = costMetrics.averageGasCost < 10;
        const slippageTarget = costMetrics.averageSlippage < 0.5;
        
        console.log(`   Gas Cost Target (<$10): ${gasTarget ? '✅ PASS' : '❌ FAIL'}`);
        console.log(`   Slippage Target (<0.5%): ${slippageTarget ? '✅ PASS' : '❌ FAIL'}`);
        
        return {
          costMetrics,
          gasTarget,
          slippageTarget,
          passed: gasTarget && slippageTarget
        };
      });

    } catch (error) {
      console.error(chalk.red('❌ Performance tests failed:'), error.message);
    }
  }

  async runTest(testName, testFunction) {
    try {
      console.log(chalk.yellow(`\n🔍 Running: ${testName}`));
      const startTime = Date.now();
      
      const result = await testFunction();
      
      const executionTime = Date.now() - startTime;
      console.log(chalk.green(`✅ ${testName} - PASSED (${executionTime}ms)`));
      
      this.results.overall.passed++;
      this.results.overall.total++;
      
      return result;
    } catch (error) {
      console.error(chalk.red(`❌ ${testName} - FAILED: ${error.message}`));
      
      this.results.overall.failed++;
      this.results.overall.total++;
      
      throw error;
    }
  }

  async confirmAction(message) {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    return new Promise((resolve) => {
      rl.question(chalk.yellow(`\n⚠️  ${message} (y/N): `), (answer) => {
        rl.close();
        resolve(answer.toLowerCase() === 'y' || answer.toLowerCase() === 'yes');
      });
    });
  }

  async generateReport() {
    console.log(chalk.blue('\n📊 Generating Test Report...'));
    
    const report = {
      timestamp: new Date().toISOString(),
      network: this.network,
      testMode: this.testMode,
      summary: {
        totalTests: this.results.overall.total,
        passed: this.results.overall.passed,
        failed: this.results.overall.failed,
        successRate: `${((this.results.overall.passed / this.results.overall.total) * 100).toFixed(2)}%`
      },
      results: this.results
    };

    // Display summary
    console.log(chalk.cyan('\n📈 Test Summary:'));
    console.log(`   Total Tests: ${report.summary.totalTests}`);
    console.log(`   Passed: ${chalk.green(report.summary.passed)}`);
    console.log(`   Failed: ${chalk.red(report.summary.failed)}`);
    console.log(`   Success Rate: ${report.summary.successRate}`);

    // Save report
    const fs = require('fs');
    const reportPath = `./test-reports/mainnet-validation-${Date.now()}.json`;
    
    if (!fs.existsSync('./test-reports')) {
      fs.mkdirSync('./test-reports', { recursive: true });
    }
    
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    console.log(chalk.blue(`\n💾 Report saved to: ${reportPath}`));

    return report;
  }

  async run() {
    console.log(chalk.bold.blue('\n🚀 POLLEN TRADING BOT - MAINNET VALIDATION\n'));
    
    // Initialize
    const initialized = await this.initialize();
    if (!initialized) {
      process.exit(1);
    }

    // Run test suites
    await this.testPLNStaking();
    await this.testPortfolioRebalancing();
    await this.testRiskManagement();
    await this.testPerformance();

    // Generate report
    const report = await this.generateReport();

    // Final status
    if (report.summary.failed === 0) {
      console.log(chalk.bold.green('\n🎉 ALL TESTS PASSED - READY FOR MAINNET DEPLOYMENT!'));
    } else {
      console.log(chalk.bold.red('\n⚠️  SOME TESTS FAILED - REVIEW BEFORE DEPLOYMENT'));
    }

    return report;
  }
}

// CLI execution
if (require.main === module) {
  const args = process.argv.slice(2);
  const options = {};
  
  args.forEach(arg => {
    if (arg.startsWith('--network=')) {
      options.network = arg.split('=')[1];
    }
    if (arg.startsWith('--test-mode=')) {
      options.testMode = arg.split('=')[1];
    }
  });

  const validator = new MainnetValidator(options);
  validator.run().catch(console.error);
}

module.exports = MainnetValidator; 