const { ethers } = require('ethers');
require('dotenv').config();

// Configuration
const RPC_URL = 'https://sepolia.base.org';
const PRIVATE_KEY = process.env.PRIVATE_KEY; // Make sure to set this in your .env file

// Pollen Protocol addresses on Base Sepolia
const POLLEN_DAO_ADDRESS = '0xEF789258233E6cFBB5E0bb093FC9537E69e81Bb7';
const VE_PLN_ADDRESS = '0x3a28AB567b661B3edaF9Ef0bDE9489558EDB3995';

// ABI for PollenDAO - Simplified to include only necessary functions
const POLLEN_DAO_ABI = [
  'function createPortfolio(uint256 amount, uint256[] calldata weights, bool[] calldata shorts, bool tokenType)',
  'function rebalancePortfolio(uint256[] calldata newWeights, bool[] calldata newShorts, uint256 amount, bool tokenType)',
  'function getPortfolio(address owner) external view returns (address, uint256[] memory, uint256, uint256)',
  'function getPortfolio1(address owner, address delegate) external view returns (address, uint256[] memory, uint256, uint256, bool[] memory, uint256)'
];

// ABI for vePLN token
const VE_PLN_ABI = [
  'function approve(address spender, uint256 amount) external returns (bool)',
  'function allowance(address owner, address spender) external view returns (uint256)',
  'function balanceOf(address account) external view returns (uint256)'
];

class PollenBot {
  constructor() {
    this.provider = new ethers.providers.JsonRpcProvider(RPC_URL);
    this.wallet = new ethers.Wallet(PRIVATE_KEY, this.provider);
    
    // Initialize contracts
    this.pollenDao = new ethers.Contract(POLLEN_DAO_ADDRESS, POLLEN_DAO_ABI, this.wallet);
    this.vePln = new ethers.Contract(VE_PLN_ADDRESS, VE_PLN_ABI, this.wallet);
  }

  // Check wallet balance of vePLN
  async checkBalance() {
    const balance = await this.vePln.balanceOf(this.wallet.address);
    console.log(`vePLN Balance: ${ethers.utils.formatEther(balance)}`);
    return balance;
  }

  // Approve PollenDAO to spend vePLN
  async approvePollenDao(amount) {
    const allowance = await this.vePln.allowance(this.wallet.address, POLLEN_DAO_ADDRESS);
    
    if (allowance.lt(amount)) {
      console.log('Approving PollenDAO to spend vePLN...');
      const tx = await this.vePln.approve(POLLEN_DAO_ADDRESS, amount);
      await tx.wait();
      console.log('Approval successful');
    } else {
      console.log('Sufficient allowance already set');
    }
  }

  // Create a new portfolio
  async createPortfolio(amount, weights, shorts, isVePln = true) {
    try {
      console.log('Creating portfolio...');
      
      // Convert amount to wei
      const amountWei = ethers.utils.parseEther(amount.toString());
      
      // Approve tokens if needed
      await this.approvePollenDao(amountWei);
      
      // Create portfolio
      const tx = await this.pollenDao.createPortfolio(
        amountWei,
        weights,
        shorts,
        isVePln,
        { gasLimit: 1000000 }
      );
      
      const receipt = await tx.wait();
      console.log('Portfolio created successfully!');
      console.log('Transaction hash:', receipt.transactionHash);
      
      // Try to find the portfolio address in the transaction receipt
      await this.findPortfolioAddress(receipt.transactionHash);
      
      return receipt;
    } catch (error) {
      console.error('Error creating portfolio:', error);
      throw error;
    }
  }

  // Rebalance an existing portfolio
  async rebalancePortfolio(newWeights, newShorts, amount = '0', isVePln = true) {
    try {
      console.log('Rebalancing portfolio...');
      
      // Convert amount to wei
      const amountWei = ethers.utils.parseEther(amount.toString());
      
      // Approve additional tokens if needed
      if (amountWei.gt(0)) {
        await this.approvePollenDao(amountWei);
      }
      
      // Rebalance portfolio
      const tx = await this.pollenDao.rebalancePortfolio(
        newWeights,
        newShorts,
        amountWei,
        isVePln,
        { gasLimit: 1000000 }
      );
      
      const receipt = await tx.wait();
      console.log('Portfolio rebalanced successfully!');
      console.log('Transaction hash:', receipt.transactionHash);
      
      return receipt;
    } catch (error) {
      console.error('Error rebalancing portfolio:', error);
      throw error;
    }
  }

  // Get portfolio details
  async getPortfolio() {
    try {
      console.log('Fetching portfolio details...');
      
      // Try the newer getPortfolio1 function first
      let portfolio;
      try {
        portfolio = await this.pollenDao.getPortfolio1(this.wallet.address, this.wallet.address);
        console.log('Portfolio details (v1):', {
          portfolioAddress: portfolio[0],
          amounts: portfolio[1].map(a => a.toString()),
          totalValue: portfolio[2].toString(),
          timestamp: new Date(portfolio[3].toNumber() * 1000).toISOString(),
          shorts: portfolio[4],
          shortValue: portfolio[5].toString()
        });
      } catch (e) {
        // Fall back to the older getPortfolio function
        console.log('Falling back to older getPortfolio function...');
        portfolio = await this.pollenDao.getPortfolio(this.wallet.address);
        console.log('Portfolio details (legacy):', {
          portfolioAddress: portfolio[0],
          amounts: portfolio[1].map(a => a.toString()),
          totalValue: portfolio[2].toString(),
          timestamp: new Date(portfolio[3].toNumber() * 1000).toISOString()
        });
      }
      
      return portfolio;
    } catch (error) {
      console.error('Error fetching portfolio:', error);
      throw error;
    }
  }

  // Helper function to find portfolio address in transaction receipt
  async findPortfolioAddress(txHash) {
    try {
      const receipt = await this.provider.getTransactionReceipt(txHash);
      
      // Look for PortfolioCreated event
      const iface = new ethers.utils.Interface([
        'event PortfolioCreated(address indexed creator, uint256 amount, uint256[] weights, bool tokenType)'
      ]);
      
      for (const log of receipt.logs) {
        try {
          const parsedLog = iface.parseLog(log);
          if (parsedLog && parsedLog.name === 'PortfolioCreated') {
            console.log('Portfolio created for:', parsedLog.args.creator);
            console.log('Amount staked:', ethers.utils.formatEther(parsedLog.args.amount));
            console.log('Weights:', parsedLog.args.weights.map(w => w.toString()));
            
            // The portfolio address is not directly in the event, so we'll need to get it from the contract
            const portfolio = await this.getPortfolio();
            if (portfolio && portfolio[0] !== ethers.constants.AddressZero) {
              console.log('Portfolio address:', portfolio[0]);
              return portfolio[0];
            }
          }
        } catch (e) {
          // Not the log we're looking for
          continue;
        }
      }
      
      console.log('Could not find portfolio address in transaction receipt');
      return null;
    } catch (error) {
      console.error('Error finding portfolio address:', error);
      return null;
    }
  }
}

// Example usage
async function main() {
  const bot = new PollenBot();
  
  try {
    // Check balance
    await bot.checkBalance();
    
    // Example: Create a new portfolio
    // const weights = [ethers.BigNumber.from('5000'), ethers.BigNumber.from('5000')]; // 50% each
    // const shorts = [false, false]; // Not shorting any assets
    // await bot.createPortfolio('10', weights, shorts); // 10 vePLN
    
    // Example: Rebalance existing portfolio
    // const newWeights = [ethers.BigNumber.from('3000'), ethers.BigNumber.from('7000')]; // 30/70 split
    // const newShorts = [false, false];
    // await bot.rebalancePortfolio(newWeights, newShorts);
    
    // Get current portfolio
    await bot.getPortfolio();
    
  } catch (error) {
    console.error('Error in main:', error);
  }
}

// Run the bot
if (require.main === module) {
  main().catch(console.error);
}

module.exports = PollenBot;
