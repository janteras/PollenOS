require('dotenv').config({ path: require('path').resolve(__dirname, '.wallets') });
const { ethers, utils } = require('ethers');
const axios = require('axios');
const { SMA, RSI, MACD } = require('technicalindicators');
const { EventEmitter } = require('events');
const PortfolioManager = require('./portfolio-manager');

// Configuration
const CONFIG = {
  // Trading parameters
  MAX_POSITION_SIZE: 0.2, // 20% max per position
  STOP_LOSS: 0.05, // 5% stop loss
  TAKE_PROFIT: 0.1, // 10% take profit
  REBALANCE_THRESHOLD: 0.05, // 5% threshold for rebalancing
  
  // Technical analysis
  RSI_PERIOD: 14,
  RSI_OVERBOUGHT: 70,
  RSI_OVERSOLD: 30,
  
  // API endpoints
  COINGECKO_API: 'https://api.coingecko.com/api/v3',
  
  // Event listeners
  EVENT_POLL_INTERVAL: 15000, // 15 seconds
  MAX_BLOCK_LOOKBACK: 1000
};

class AdvancedTradingBot extends EventEmitter {
  constructor() {
    super();
    this.portfolioManager = new PortfolioManager();
    this.wallet = this.portfolioManager.wallet;
    this.logger = this.portfolioManager.logger;
    this.provider = this.portfolioManager.provider;
    this.portfolio = this.portfolioManager.portfolio;
    this.isRunning = false;
    this.eventHandlers = new Map();
    this.lastProcessedBlock = 0;
    
    // Initialize event listeners
    this.initializeEventListeners();
  }

  // ===== CORE TRADING METHODS =====
  
  /**
   * Start the trading bot with event listeners and strategy execution
   */
  async start() {
    if (this.isRunning) {
      this.logger.warn('Bot is already running');
      return;
    }
    
    this.isRunning = true;
    this.logger.info('🚀 Starting trading bot...');
    this.emit('start');
    
    try {
      // Start event listeners
      await this.startEventListeners();
      
      // Initial execution
      await this.executeStrategy();
      
      // Schedule periodic strategy execution (e.g., every hour)
      this.strategyInterval = setInterval(
        async () => {
          try {
            await this.executeStrategy();
          } catch (error) {
            this.logger.error('Error in scheduled strategy execution:', error);
            this.emit('error', error);
          }
        },
        60 * 60 * 1000 // 1 hour
      );
      
      return true;
    } catch (error) {
      this.logger.error('Failed to start bot:', error);
      this.emit('error', error);
      this.stop();
      throw error;
    }
  }
  
  /**
   * Stop the trading bot
   */
  async executeStrategy() {
    if (!this.isRunning) return;
    
    const startTime = Date.now();
    this.emit('strategy:start', {
      strategy: 'momentum',
      timestamp: new Date().toISOString(),
      blockNumber: await this.provider.getBlockNumber()
    });
    
    try {
      // 1. Get current portfolio state
      const portfolio = await this.portfolioManager.getPortfolioDetails(this.wallet.address);
      this.emit('portfolio:update', portfolio);
      
      // 2. Fetch market data
      const marketData = await this.fetchMarketData();
      this.emit('market:update', { prices: marketData });
      
      // 3. Generate trading signals (simplified example)
      const signals = {};
      for (const [symbol, data] of Object.entries(marketData)) {
        signals[symbol] = {
          action: data.priceChange24h > 0 ? 'buy' : 'sell',
          confidence: Math.min(100, Math.abs(data.priceChange24h) * 2)
        };
      }
      
      // 4. Generate target allocation (simplified example)
      const allocation = await this.generateTargetAllocation(portfolio, signals);
      
      // 5. Apply risk management
      const riskAdjustedAllocation = this.applyRiskManagement(allocation, portfolio);
      
      // 6. Execute rebalance if needed
      if (this.shouldRebalance(portfolio, riskAdjustedAllocation)) {
        await this.rebalancePortfolio(riskAdjustedAllocation);
      }
      
      // 7. Emit completion event
      this.emit('strategy:complete', {
        success: true,
        duration: Date.now() - startTime,
        allocation: riskAdjustedAllocation
      });
      
      return riskAdjustedAllocation;
      
    } catch (error) {
      this.logger.error('Error in strategy execution:', error);
      this.emit('strategy:complete', {
        success: false,
        duration: Date.now() - startTime,
        error: error.message
      });
      throw error;
    }
  }
  
  async stop() {
    if (!this.isRunning) return;
    
    this.isRunning = false;
    clearInterval(this.strategyInterval);
    await this.stopEventListeners();
    this.logger.info('🛑 Trading bot stopped');
    this.emit('stop');
  }

  // ===== PORTFOLIO MANAGEMENT =====
  
  async generateTargetAllocation(portfolio, signals) {
    // This is a simplified example - in a real implementation, you would:
    // 1. Analyze current portfolio
    // 2. Apply trading signals
    // 3. Generate target weights
    
    // For now, return a balanced allocation
    const assetCount = portfolio.assetAmounts.length;
    const weight = Math.floor(10000 / assetCount); // Equal weight in basis points
    
    return {
      weights: Array(assetCount).fill(weight),
      isShort: Array(assetCount).fill(false)
    };
  }
  
  applyRiskManagement(allocation, portfolio) {
    // Apply position sizing, stop-loss, take-profit, etc.
    // This is a simplified example
    return allocation;
  }
  
  shouldRebalance(portfolio, targetAllocation) {
    // Check if rebalancing is needed based on current vs target allocation
    // This is a simplified example
    return true;
  }
  
  async rebalancePortfolio(allocation) {
    try {
      this.logger.info('Executing portfolio rebalance...');
      await this.portfolioManager.rebalancePortfolio(
        allocation.weights,
        allocation.isShort
      );
      
      // Get updated portfolio
      const updated = await this.portfolioManager.getPortfolioDetails(this.wallet.address);
      this.emit('rebalance', {
        weights: allocation.weights,
        isShort: allocation.isShort,
        txHash: 'pending', // In a real implementation, you'd get this from the transaction
        timestamp: new Date().toISOString()
      });
      
      return updated;
    } catch (error) {
      this.logger.error('Error rebalancing portfolio:', error);
      this.emit('error', error);
      throw error;
    }
  }
  
  // ===== MARKET DATA =====
  
  async fetchMarketData() {
    try {
      this.logger.info('Fetching market data...');
      
      // Example: Fetch prices from Coingecko
      const response = await axios.get(`${CONFIG.COINGECKO_API}/coins/markets`, {
        params: {
          vs_currency: 'usd',
          ids: 'bitcoin,ethereum,chainlink,usd-coin,tether,dai,chainlink',
          price_change_percentage: '24h,7d',
          per_page: 7
        }
      });
      
      // Process and return market data
      return response.data.reduce((acc, coin) => {
        const symbol = coin.symbol.toUpperCase();
        acc[symbol] = {
          price: coin.current_price,
          priceChange24h: coin.price_change_percentage_24h || 0,
          priceChange7d: coin.price_change_percentage_7d_in_currency || 0,
          marketCap: coin.market_cap,
          volume: coin.total_volume,
          lastUpdated: coin.last_updated
        };
        return acc;
      }, {});
      
    } catch (error) {
      this.logger.error('Error fetching market data:', error.message);
      throw error;
    }
  }

  // ===== EVENT LISTENERS =====
  
  /**
   * Initialize event listeners
   */
  initializeEventListeners() {
    // Portfolio created event
    this.eventHandlers.set('PortfolioCreated', (owner, assets, amounts, event) => {
      this.logger.info(`\n📝 New Portfolio Created`);
      this.logger.info(`Owner: ${owner}`);
      this.logger.info(`Initial Assets: ${assets}`);
      this.logger.info(`Initial Amounts: ${amounts}`);
      this.logger.info(`Tx: ${event.transactionHash}`);
    });

    // Portfolio rebalanced event
    this.eventHandlers.set('Rebalanced', (owner, newWeights, isShort, event) => {
      this.logger.info(`\n🔄 Portfolio Rebalanced`);
      this.logger.info(`Owner: ${owner}`);
      this.logger.info(`New Weights: ${newWeights}`);
      this.logger.info(`Short Positions: ${isShort}`);
      this.logger.info(`Tx: ${event.transactionHash}`);
    });

    // Deposit event
    this.eventHandlers.set('Deposit', (user, amount, event) => {
      this.logger.info(`\n💵 Deposit Received`);
      this.logger.info(`From: ${user}`);
      this.logger.info(`Amount: ${ethers.utils.formatEther(amount)} PLN`);
      this.logger.info(`Tx: ${event.transactionHash}`);
    });
  }

  /**
   * Start listening for events
   */
  async startEventListeners() {
    if (this.eventPollingInterval) return;
    
    // Get current block number
    const currentBlock = await this.provider.getBlockNumber();
    this.lastProcessedBlock = Math.max(0, currentBlock - CONFIG.MAX_BLOCK_LOOKBACK);
    
    // Set up polling interval
    this.eventPollingInterval = setInterval(
      () => this.pollEvents(),
      CONFIG.EVENT_POLL_INTERVAL
    );
    
    this.logger.info(`👂 Listening for events from block ${this.lastProcessedBlock}`);
  }
  
  /**
   * Stop listening for events
   */
  stopEventListeners() {
    if (this.eventPollingInterval) {
      clearInterval(this.eventPollingInterval);
      this.eventPollingInterval = null;
    }
  }
  
  /**
   * Poll for new events
   */
  async pollEvents() {
    try {
      const currentBlock = await this.provider.getBlockNumber();
      const fromBlock = this.lastProcessedBlock + 1;
      
      if (fromBlock > currentBlock) return;
      
      // Process each event type
      for (const [eventName, handler] of this.eventHandlers.entries()) {
        const events = await this.portfolio.queryFilter(
          eventName,
          fromBlock,
          currentBlock
        );
        
        for (const event of events) {
          try {
            await handler(...event.args, event);
          } catch (error) {
            this.logger.error(`Error handling ${eventName} event:`, error);
          }
        }
      }
      
      this.lastProcessedBlock = currentBlock;
    } catch (error) {
      this.logger.error('Error polling events:', error);
    }
  }
}

// Export the bot class
module.exports = AdvancedTradingBot;
