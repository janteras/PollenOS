require('dotenv').config({ path: require('path').resolve(__dirname, '../base-sepolia.env') });
const { ethers } = require('ethers');

// Contract ABIs
const LockedPollenABI = [
  'function create_lock(uint256 _value, uint256 _unlock_time) external',
  'function balanceOf(address owner) view returns (uint256)',
// Base Sepolia Contract Addresses
const CONFIG = {
  RPC_URL: 'https://sepolia.base.org',
  CHAIN_ID: 84532,
  CONTRACTS: {
    PLN: '0x9E1c51E1fAa1381D8a7Dbdd19402c5fCce9274C6', // PLN Token
    VEPLN: '0x3a28AB567b661B3edaF9Ef0bDE9489558EDB3995', // vePLN Contract
    POLLEN_DAO: '0xEF789258233E6cFBB5E0bb093FC9537E69e81Bb7',
    LEAGUES: '0x55F04Ee2775925b80125F412C05cF5214Fd1317a'
  }
};

// Contract ABIs
const ERC20_ABI = [
  'function balanceOf(address) view returns (uint256)',
  'function allowance(address, address) view returns (uint256)',
  'function approve(address spender, uint256 amount) returns (bool)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)'
];

const VEPLN_ABI = [
  'function create_lock(uint256 _value, uint256 _unlock_time) external',
  'function locked(address) view returns (int128 amount, uint256 end)',
  'function token() external view returns (address)',
  'function version() external view returns (string)'
];

// Helper function to get contract info
async function getContractInfo(contract, name) {
  try {
    const info = {};
    
    // Try to get basic info
    if (contract.functions.name) {
      info.name = await contract.name();
    }
    
    if (contract.functions.symbol) {
      info.symbol = await contract.symbol();
    }
    
    if (contract.functions.decimals) {
      info.decimals = await contract.decimals();
    }
    
    if (contract.functions.version) {
      info.version = await contract.version().catch(() => 'unknown');
    }
    
    if (contract.functions.token) {
      info.token = await contract.token().catch(() => 'unknown');
    }
    
    console.log(`\n=== ${name} Contract Info ===`);
    console.log(`Address: ${contract.address}`);
    Object.entries(info).forEach(([key, value]) => {
      console.log(`${key.charAt(0).toUpperCase() + key.slice(1)}: ${value}`);
    });
    
    return info;
  } catch (error) {
    console.error(`Error getting ${name} info:`, error.message);
    return {};
  }
}

async function main() {
  console.log('🚀 Starting portfolio creation process...');
  
  // Initialize provider and wallet
  const provider = new ethers.providers.JsonRpcProvider(CONFIG.RPC_URL);
  const wallet = new ethers.Wallet(process.env.WALLET_PRIVATE_KEY, provider);
  
  console.log(`🌐 Network: Base Sepolia (Chain ID: ${(await provider.getNetwork()).chainId})`);
  console.log(`🔗 RPC URL: ${CONFIG.RPC_URL}`);
  console.log(`🔑 Wallet: ${wallet.address}`);
  
  // Check ETH balance for gas
  const ethBalance = await provider.getBalance(wallet.address);
  console.log(`💰 ETH Balance: ${ethers.utils.formatEther(ethBalance)} ETH`);
  
  if (ethBalance.lt(ethers.utils.parseEther('0.01'))) {
    throw new Error('Insufficient ETH for gas. Please fund your wallet.');
  }
  
  // Initialize contracts
  const plnToken = new ethers.Contract(CONFIG.CONTRACTS.PLN, ERC20_ABI, wallet);
  const vePln = new ethers.Contract(CONFIG.CONTRACTS.VEPLN, VEPLN_ABI, wallet);
  
  // Get contract info
  await getContractInfo(plnToken, 'PLN Token');
  await getContractInfo(vePln, 'vePLN');
  
  // Check PLN balance
  const plnBalance = await plnToken.balanceOf(wallet.address);
  console.log(`\n💰 Your PLN Balance: ${ethers.utils.formatEther(plnBalance)} PLN`);
  
  if (plnBalance.isZero()) {
    throw new Error('Insufficient PLN balance. Please acquire some PLN tokens.');
  }
  
  // Check allowance
  const allowance = await plnToken.allowance(wallet.address, CONFIG.CONTRACTS.VEPLN);
  console.log(`\n🔒 Current allowance for vePLN: ${ethers.utils.formatEther(allowance)} PLN`);
  
  // Approve vePLN to spend PLN if needed
  if (allowance.lt(plnBalance)) {
    console.log('\n🔓 Approving vePLN to spend PLN...');
    try {
      const approveTx = await plnToken.approve(
        CONFIG.CONTRACTS.VEPLN,
        ethers.constants.MaxUint256,
        {
          gasLimit: 200000, // Higher gas limit for token approvals
          gasPrice: (await provider.getGasPrice()).mul(2) // Add buffer to gas price
        }
      );
      
      console.log(`⏳ Waiting for approval confirmation...`);
      const receipt = await approveTx.wait();
      console.log(`✅ Approval confirmed in tx: ${receipt.transactionHash}`);
      console.log(`   Gas used: ${receipt.gasUsed.toString()}`);
      
      // Verify the new allowance
      const newAllowance = await plnToken.allowance(wallet.address, CONFIG.CONTRACTS.VEPLN);
      console.log(`   New allowance: ${ethers.utils.formatEther(newAllowance)} PLN`);
      
    } catch (error) {
      console.error('❌ Approval failed:', error.message);
      if (error.transactionHash) {
        console.log(`   Transaction hash: ${error.transactionHash}`);
      }
      throw error;
    }
  }
  
  // Check if already locked
  try {
    const locked = await vePln.locked(wallet.address);
    if (locked.amount.gt(0)) {
      console.log('\n🔍 Found existing locked position:');
      console.log(`   Amount: ${ethers.utils.formatEther(locked.amount)} PLN`);
      console.log(`   Unlocks at: ${new Date(locked.end * 1000).toISOString()}`);
      
      const now = Math.floor(Date.now() / 1000);
      if (locked.end > now) {
        console.log('\n⚠️  You already have a locked position. Creating a new one will replace the existing lock.');
      }
    }
  } catch (error) {
    console.log('\nℹ️  No existing locked position found or error checking lock status:', error.message);
  }
  
  // Calculate unlock time (1 year from now)
  const oneYearInSeconds = 365 * 24 * 60 * 60;
  const unlockTime = Math.floor(Date.now() / 1000) + oneYearInSeconds;
  
  // Amount to lock (all available PLN)
  const amountToLock = plnBalance;
  
  console.log(`\n🔐 Attempting to lock ${ethers.utils.formatEther(amountToLock)} PLN for 1 year...`);
  console.log(`   Unlock time: ${new Date(unlockTime * 1000).toISOString()}`);
  
  // Create lock
  try {
    console.log('\n📡 Sending create_lock transaction...');
    
    // Estimate gas first
    const gasEstimate = await vePln.estimateGas.create_lock(
      amountToLock,
      unlockTime
    ).catch(error => {
      console.error('\n⚠️  Gas estimation failed:', error.reason || error.message);
      console.log('   This might indicate an issue with the contract or parameters.');
      return ethers.BigNumber.from('1000000'); // Default gas limit if estimation fails
    });
    console.log('🚀 Starting portfolio creation process...');
    console.log('🌐 Network: Base Sepolia');
    console.log('🔗 RPC URL:', CONFIG.RPC_URL);
    
    createPortfolio(privateKey)
        .then((result) => {
            console.log('\n🎉 Portfolio creation completed successfully!');
            console.log('🔗 Transaction hash:', result.txHash);
            console.log('💰 Locked amount:', ethers.utils.formatEther(result.amount), 'PLN');
            console.log('⏰ Unlock time:', new Date(parseInt(result.unlockTime) * 1000).toLocaleString());
            process.exit(0);
        })
        .catch(error => {
            console.error('\n❌ Portfolio creation failed:');
            console.error('Error:', error.message);
            if (error.code) console.error('Code:', error.code);
            if (error.reason) console.error('Reason:', error.reason);
            if (error.transactionHash) {
                console.log('Transaction hash:', error.transactionHash);
                console.log('Check the transaction on https://sepolia.basescan.org/tx/' + error.transactionHash);
            }
            process.exit(1);
        });
}

module.exports = createPortfolio;
